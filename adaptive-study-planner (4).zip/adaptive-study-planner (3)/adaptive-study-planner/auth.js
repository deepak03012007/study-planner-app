/* ==========================================
   AUTHENTICATION SYSTEM
   ========================================== */

const FIREBASE_CONFIG = {
    apiKey: 'YOUR_API_KEY',
    authDomain: 'YOUR_PROJECT_ID.firebaseapp.com',
    projectId: 'YOUR_PROJECT_ID',
    appId: 'YOUR_APP_ID'
};

class AuthManager {
    constructor() {
        this.users = this.loadUsers();
        this.currentUser = this.getCurrentUser();
        this.useFirebase = this.canUseFirebase();
        if (this.useFirebase && !firebase.apps.length) {
            firebase.initializeApp(FIREBASE_CONFIG);
        }
        window.authManager = this;
        this.init();
    }

    canUseFirebase() {
        return typeof window.firebase !== 'undefined' && FIREBASE_CONFIG.apiKey !== 'YOUR_API_KEY';
    }

    init() {
        if (document.getElementById('loginForm')) {
            this.setupLoginForm();
        }

        if (document.getElementById('registerForm')) {
            this.setupRegisterForm();
        }

        if (document.querySelector('.container') && !this.currentUser) {
            window.location.href = 'login.html';
        }
    }

    loadUsers() {
        const stored = localStorage.getItem('studyUsers');
        return stored ? JSON.parse(stored) : {};
    }

    saveUsers() {
        localStorage.setItem('studyUsers', JSON.stringify(this.users));
    }

    getCurrentUser() {
        const stored = localStorage.getItem('currentUser');
        return stored ? JSON.parse(stored) : null;
    }

    setCurrentUser(user) {
        this.currentUser = user;
        localStorage.setItem('currentUser', JSON.stringify(user));
    }

    logout() {
        this.currentUser = null;
        localStorage.removeItem('currentUser');

        if (this.useFirebase) {
            firebase.auth().signOut().finally(() => {
                window.location.href = 'login.html';
            });
            return;
        }

        window.location.href = 'login.html';
    }

    setupLoginForm() {
        const form = document.getElementById('loginForm');
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            await this.login(email, password);
        });

        document.getElementById('resendVerificationBtn')?.addEventListener('click', async () => {
            if (!this.useFirebase) {
                this.showError('Add your Firebase config in auth.js to enable verification.');
                return;
            }

            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            if (!email || !password) {
                this.showError('Enter email and password first.');
                return;
            }

            try {
                const credentials = await firebase.auth().signInWithEmailAndPassword(email, password);
                await credentials.user.sendEmailVerification();
                await firebase.auth().signOut();
                this.showError('Verification email sent. Please verify, then log in.');
            } catch (error) {
                this.showError(error.message || 'Unable to send verification email.');
            }
        });
    }

    setupRegisterForm() {
        const form = document.getElementById('registerForm');
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            if (password !== confirmPassword) {
                this.showError('Passwords do not match');
                return;
            }

            if (this.useFirebase) {
                await this.registerWithFirebase(name, email, password);
                return;
            }

            if (this.register(name, email, password)) {
                window.location.href = 'login.html';
            } else {
                this.showError('Email already exists');
            }
        });
    }

    async login(email, password) {
        if (this.useFirebase) {
            try {
                const credentials = await firebase.auth().signInWithEmailAndPassword(email, password);

                if (!credentials.user.emailVerified) {
                    await firebase.auth().signOut();
                    this.showError('Verify your email before logging in.');
                    return false;
                }

                this.setCurrentUser({
                    email: credentials.user.email,
                    name: credentials.user.displayName || credentials.user.email.split('@')[0]
                });
                window.location.href = 'index.html';
                return true;
            } catch (error) {
                this.showError(error.message || 'Invalid email or password');
                return false;
            }
        }

        const user = this.users[email];
        if (user && user.password === password) {
            this.setCurrentUser({ email, name: user.name });
            window.location.href = 'index.html';
            return true;
        }

        this.showError('Invalid email or password');
        return false;
    }

    register(name, email, password) {
        if (this.users[email]) {
            return false;
        }

        this.users[email] = {
            name,
            password,
            createdAt: new Date().toISOString()
        };
        this.saveUsers();
        return true;
    }

    async registerWithFirebase(name, email, password) {
        try {
            const credentials = await firebase.auth().createUserWithEmailAndPassword(email, password);
            await credentials.user.updateProfile({ displayName: name });
            await credentials.user.sendEmailVerification();

            const verificationMessage = document.getElementById('verificationMessage');
            if (verificationMessage) {
                verificationMessage.textContent = 'Verification email sent. Verify your email, then log in.';
            }

            await firebase.auth().signOut();
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1500);
            return true;
        } catch (error) {
            this.showError(error.message || 'Unable to create account');
            return false;
        }
    }

    showError(message) {
        const existingError = document.querySelector('.auth-error');
        if (existingError) {
            existingError.remove();
        }

        const errorDiv = document.createElement('div');
        errorDiv.className = 'auth-error';
        errorDiv.textContent = message;

        const form = document.querySelector('.auth-form');
        form.insertBefore(errorDiv, form.firstChild);

        setTimeout(() => {
            if (errorDiv.parentNode) {
                errorDiv.remove();
            }
        }, 3000);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new AuthManager();
});
