class AdaptiveStudyPlanner {
    generatePlan(profile) {
        const today = this.startOfDay(new Date());
        const examDate = this.startOfDay(this.parseDateInput(profile.examDate));
        const daysUntilExam = Math.ceil((examDate - today) / 86400000);

        if (!profile || !profile.subjects || profile.subjects.length === 0) {
            return { error: 'Add at least one subject with topics before generating a plan.' };
        }

        if (Number.isNaN(examDate.getTime()) || daysUntilExam <= 0) {
            return { error: 'Exam date must be a future date.' };
        }

        const subjectCount = profile.subjects.length;
        const dailyHours = Math.max(subjectCount, Number(profile.availableHours || 0));
        const dailyDates = this.buildStudyDates(today, examDate);
        const difficultyWeights = { easy: 1, moderate: 2, difficult: 3 };
        const totalAvailableHours = daysUntilExam * dailyHours;
        const subjectQueues = profile.subjects.map((subject) => ({
            subjectId: subject.id,
            subjectName: subject.name,
            difficulty: subject.difficulty || 'moderate',
            weight: difficultyWeights[subject.difficulty] || 2,
            topics: subject.topics
                .filter((topic) => !topic.completed)
                .map((topic) => ({
                    topicId: topic.id,
                    topicName: topic.name,
                    remainingHours: this.estimateTopicHours(topic.name)
                }))
        }));
        const totalRequiredHours = subjectQueues.reduce((sum, subject) => (
            sum + subject.topics.reduce((topicSum, topic) => topicSum + topic.remainingHours, 0)
        ), 0);

        if (!totalRequiredHours) {
            return {
                daysUntilExam,
                totalAvailableHours,
                totalRequiredHours,
                remainingTopics: 0,
                sessions: [],
                recommendation: 'All topics are marked complete. Use the remaining time for revision and mock tests.'
            };
        }

        const sessions = [];
        const remainingTopics = () => subjectQueues.reduce((sum, subject) => sum + subject.topics.length, 0);

        dailyDates.forEach((date) => {
            const localDateKey = this.toLocalDateKey(date);
            const allocations = this.buildDailySubjectAllocations(subjectQueues, dailyHours);

            allocations.forEach((allocation) => {
                const subjectState = subjectQueues.find((subject) => subject.subjectId === allocation.subjectId);
                const studyFocus = this.consumeTopicsForAllocation(subjectState, allocation.durationHours);

                sessions.push({
                    id: `${localDateKey}-${allocation.subjectId}`,
                    date: localDateKey,
                    dateLabel: date.toLocaleDateString('en-US', {
                        weekday: 'short',
                        month: 'short',
                        day: 'numeric'
                    }),
                    subjectId: allocation.subjectId,
                    subjectName: allocation.subjectName,
                    topicId: studyFocus.topicIds.join('|') || `${allocation.subjectId}-revision`,
                    topicName: studyFocus.topicLabel,
                    durationHours: allocation.durationHours,
                    status: 'pending'
                });
            });
        });

        return {
            generatedAt: new Date().toISOString(),
            daysUntilExam,
            totalAvailableHours,
            totalRequiredHours,
            remainingTopics: remainingTopics(),
            sessions,
            recommendation: this.buildRecommendation(daysUntilExam, totalAvailableHours, totalRequiredHours)
        };
    }

    buildDailySubjectAllocations(subjectQueues, dailyHours) {
        const minimumTotal = subjectQueues.length;
        const extraHours = Math.max(0, dailyHours - minimumTotal);
        const totalWeight = subjectQueues.reduce((sum, subject) => sum + subject.weight, 0) || 1;

        return subjectQueues.map((subject) => ({
            subjectId: subject.subjectId,
            subjectName: subject.subjectName,
            durationHours: Number((1 + (extraHours * subject.weight) / totalWeight).toFixed(2))
        }));
    }

    consumeTopicsForAllocation(subjectState, allocatedHours) {
        if (!subjectState?.topics?.length) {
            return {
                topicIds: [],
                topicLabel: `Revision (${subjectState?.difficulty || 'moderate'})`
            };
        }

        let remainingHours = allocatedHours;
        const topicNames = [];
        const topicIds = [];

        while (remainingHours > 0 && subjectState.topics.length) {
            const currentTopic = subjectState.topics[0];
            if (!topicIds.includes(currentTopic.topicId)) {
                topicIds.push(currentTopic.topicId);
                topicNames.push(currentTopic.topicName);
            }

            currentTopic.remainingHours -= remainingHours;
            if (currentTopic.remainingHours <= 0) {
                remainingHours = Math.abs(currentTopic.remainingHours);
                subjectState.topics.shift();
            } else {
                remainingHours = 0;
            }
        }

        return {
            topicIds,
            topicLabel: topicNames.join(', ') || `Revision (${subjectState.difficulty})`
        };
    }

    estimateTopicHours(topicName) {
        const words = topicName.trim().split(/\s+/).filter(Boolean).length;
        if (words >= 5) return 2;
        if (words >= 3) return 1.5;
        return 1;
    }

    buildRecommendation(daysUntilExam, totalAvailableHours, totalRequiredHours) {
        if (daysUntilExam <= 7) {
            return 'Final stretch: stay consistent, revise daily, and use quizzes to strengthen weak topics.';
        }
        if (totalRequiredHours > totalAvailableHours) {
            return 'Time is tight. Focus on your highest-priority topics first and keep each study block focused.';
        }
        if (totalAvailableHours - totalRequiredHours >= 10) {
            return 'You have enough buffer time. Use it for revision, quizzes, and recovering from missed days.';
        }
        return 'Your schedule is balanced. Follow the daily plan closely and complete quizzes after each topic.';
    }

    buildStudyDates(today, examDate) {
        const dates = [];
        const cursor = new Date(today);
        while (cursor < examDate) {
            dates.push(new Date(cursor));
            cursor.setDate(cursor.getDate() + 1);
        }
        return dates;
    }

    startOfDay(date) {
        const clone = new Date(date);
        clone.setHours(0, 0, 0, 0);
        return clone;
    }

    parseDateInput(value) {
        if (!value) return new Date('');
        if (value instanceof Date) return new Date(value);
        if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
            const [year, month, day] = value.split('-').map(Number);
            return new Date(year, month - 1, day);
        }
        return new Date(value);
    }

    toLocalDateKey(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
}

const planner = new AdaptiveStudyPlanner();

function generateAdvancedStudyPlan({
    subjects = [],
    subjectDifficulties = {},
    dailyHours = 0,
    startHour = 8,
    startDate = new Date(),
    monthlyDays = 30,
    weeklyDays = 7
} = {}) {
    const normalizedSubjects = subjects.filter((subject) => Array.isArray(subject.topics) && subject.topics.length);
    const safeDailyHours = Math.max(normalizedSubjects.length, Number(dailyHours || 0));

    const getPriorityWeight = (subjectName) => {
        const difficulty = subjectDifficulties[subjectName] || 'moderate';
        const weights = { easy: 1, moderate: 2, difficult: 3 };
        return weights[difficulty] || weights.moderate;
    };

    const createSubjectQueues = () => normalizedSubjects.map((subject) => ({
        name: subject.name,
        topics: subject.topics
            .filter((topic) => !topic.completed)
            .map((topic) => typeof topic === 'string' ? { name: topic } : topic)
    }));

    const formatHour = (value) => {
        const totalMinutes = Math.round(value * 60);
        const hours = String(Math.floor(totalMinutes / 60)).padStart(2, '0');
        const minutes = String(totalMinutes % 60).padStart(2, '0');
        return `${hours}:${minutes}`;
    };

    const buildDailyAllocation = () => {
        const minimumHours = normalizedSubjects.map((subject) => ({
            subjectName: subject.name,
            hours: 1
        }));
        const extraHours = Math.max(0, safeDailyHours - normalizedSubjects.length);
        const totalWeight = normalizedSubjects.reduce((sum, subject) => sum + getPriorityWeight(subject.name), 0) || 1;

        minimumHours.forEach((entry) => {
            const weightedExtra = extraHours * (getPriorityWeight(entry.subjectName) / totalWeight);
            entry.hours = Number((entry.hours + weightedExtra).toFixed(2));
        });

        return minimumHours;
    };

    const buildSessionsForDate = (subjectQueues) => {
        const dailyAllocation = buildDailyAllocation();
        let cursor = Number(startHour || 8);

        return dailyAllocation.map((allocation) => {
            const queue = subjectQueues.find((subject) => subject.name === allocation.subjectName);
            const nextTopic = queue?.topics?.shift();
            const startTime = formatHour(cursor);
            cursor += allocation.hours;
            const endTime = formatHour(cursor);

            return {
                subject: allocation.subjectName,
                topic: nextTopic?.name || 'Revision / Carry Forward',
                durationHours: allocation.hours,
                startTime,
                endTime
            };
        });
    };

    const buildRangePlan = (days) => {
        const subjectQueues = createSubjectQueues();

        return Array.from({ length: days }, (_, index) => {
            const currentDate = new Date(startDate);
            currentDate.setDate(currentDate.getDate() + index);

            return {
                date: currentDate.toISOString().slice(0, 10),
                sessions: buildSessionsForDate(subjectQueues)
            };
        });
    };

    return {
        monthlyPlan: buildRangePlan(monthlyDays),
        weeklyPlan: buildRangePlan(weeklyDays),
        dailyPlan: buildRangePlan(1),
        hourlySchedule: buildSessionsForDate(createSubjectQueues())
    };
}

window.generateAdvancedStudyPlan = generateAdvancedStudyPlan;
