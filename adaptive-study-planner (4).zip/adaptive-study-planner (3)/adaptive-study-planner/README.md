# 🎓 AI-Based Adaptive Study Planner for Computer Engineering Students

A modern, responsive web application that intelligently adapts to your learning style and helps you prepare for Computer Engineering exams with personalized study schedules.

## 🌟 Features

### 1. **Intelligent Dashboard**
- Real-time progress tracking with circular progress indicators
- Study streak counter with motivational messages 🔥
- Daily tasks management
- Subject-wise progress visualization (Pie Chart)
- AI-powered insights and recommendations
- Accuracy rate monitoring

### 2. **Comprehensive Subject Coverage**
Four core Computer Engineering subjects with real-world content:
- **Mathematics** (Calculus, Linear Algebra, Discrete Math)
- **Operating Systems** (Process Management, Memory Management, File Systems)
- **C Programming** (Pointers & Arrays, Strings & Functions, Structures & File I/O)
- **Java** (OOP Concepts, Collections & Generics, Multithreading)

### 3. **Adaptive Learning Engine**
The app intelligently adapts to your performance:
- **Low Accuracy (<60%)** → Reduced difficulty + Topic repetition + Extra practice
- **Medium Accuracy (60-80%)** → Maintain difficulty + Introduce new topics
- **High Accuracy (>80%)** → Increased difficulty + Advanced problems
- Tracks weak areas and recommends focused study

### 4. **MCQ System**
- 50+ Quality MCQs across all subjects
- Multi-level difficulty (Easy, Medium, Hard)
- Instant feedback with detailed explanations
- Score tracking and accuracy calculation
- Progress persistence

### 5. **Smart Study Planner**
- Input your available study hours per day
- Specify exam date
- Intelligent allocation of time to subjects
- Weak subjects receive 60% more study time
- Daily schedule generation with specific activities
- Adaptive recommendations based on available time

### 6. **Task Management**
- Create, edit, and delete study tasks
- Categorize by subject (Mathematics, OS, C Programming, Java)
- Mark tasks as completed
- Filter by completion status
- Track productivity

### 7. **Progress Analytics**
- Subject Performance Bar Chart
- Weekly Performance Line Chart
- Accuracy Trend Analysis
- Difficulty Distribution Pie Chart
- Detailed Statistics Table
- All charts use Chart.js for interactive visualizations

### 8. **Modern UI/UX**
- **Glassmorphism Design** - Modern frosted glass effect cards
- **Dark/Light Mode** - Toggle between themes
- **Responsive Design** - Works perfectly on desktop, tablet, and mobile
- **Smooth Animations** - Fluid transitions and micro-interactions
- **Sidebar Navigation** - Easy access to all features
- **Real-time Clock** - Current date and time display

### 9. **Data Persistence**
- All progress saved in localStorage (no backend needed)
- Tasks automatically saved
- MCQ scores preserved
- Study streaks maintained
- Theme preference remembered

## 🛠️ Tech Stack

- **HTML5** - Semantic markup
- **CSS3** - Modern styling with glassmorphism, flexbox, grid, animations
- **Vanilla JavaScript** - No dependencies (except Chart.js)
- **Chart.js** - Beautiful, responsive charts
- **LocalStorage API** - Data persistence

## 📁 File Structure

```
adaptive-study-planner/
├── index.html           # Main HTML file with page structure
├── style.css            # Complete styling with animations
├── script.js            # Main application logic (2000+ lines)
├── mcqData.js           # MCQ database with 50+ questions
├── planner.js           # Study planner algorithm
└── README.md            # This file
```

## 🚀 Getting Started

### Quick Start
1. Download all files to a folder
2. Open `index.html` in any modern web browser
3. Start creating tasks and taking MCQs!

### No Installation Required
- No npm, no build process
- No database setup needed
- Works completely offline
- Data stored locally in your browser

## 📚 How to Use

### Dashboard
1. View your overall progress percentage
2. Check your study streak
3. See today's tasks
4. Get AI recommendations
5. Read motivational quotes

### Study Subjects
1. Click on any subject card
2. Select a topic to view details
3. Click on a topic to start MCQ session
4. Answer questions and get instant feedback
5. View your accuracy for each topic

### Take MCQs
1. Navigate to Subjects → Select Subject → Pick Topic
2. Answer questions one by one
3. Get immediate feedback with explanations
4. View your final score
5. Progress is automatically saved

### Generate Study Plan
1. Go to Study Planner
2. Enter available hours per day (1-12)
3. Select your exam date
4. Choose weak subjects (optional)
5. Get a personalized day-by-day study schedule

### Manage Tasks
1. Go to Tasks section
2. Add new tasks with category
3. Check off completed tasks
4. Filter by All/Completed/Pending
5. Delete tasks when done

### View Progress
1. Navigate to Progress section
2. Analyze your subject performance
3. Track weekly productivity
4. See accuracy improvements over time
5. Identify areas needing work

## 🧠 AI Adaptive Engine

### How It Works
1. **Performance Tracking**: App monitors your MCQ scores and accuracy
2. **Area Identification**: Weak areas (< 50% accuracy) are flagged
3. **Recommendation Engine**: 
   - Low scores → Get recommendations to repeat topics
   - High scores → Suggestions to tackle harder problems
   - Balanced → Continue balanced practice
4. **Dynamic Allocation**: Study planner allocates 60% more time to weak subjects

### Example
- You score 45% on "Pointers & Arrays" → App recommends focused practice
- You score 85% on "Discrete Math" → App suggests "Linear Algebra" as next
- You have 10 days until exam with 3 hours/day → 30 total hours
  - Mathematics (weak): 12 hours
  - OS (medium): 8 hours
  - C Programming (weak): 8 hours
  - Java (strong): 2 hours

## 📊 Data Stored

The app stores the following in localStorage:
- `studyProgress` - Progress on each subject, streak, MCQ scores
- `studyTasks` - All tasks with completion status
- `theme` - Dark/Light mode preference

## 🎨 Customization

### Add More MCQs
Edit `mcqData.js`:
```javascript
'New Topic': {
    difficulty: 'medium',
    mcqs: [
        {
            question: 'Your question here?',
            options: ['Option A', 'Option B', 'Option C', 'Option D'],
            correct: 0,
            explanation: 'Why this answer is correct...'
        }
    ]
}
```

### Modify Colors
Edit `style.css` root variables:
```css
:root {
    --primary-color: #6366f1;
    --secondary-color: #8b5cf6;
    --accent-color: #ec4899;
    /* ... more colors */
}
```

### Adjust Difficulty Levels
Modify in `mcqData.js` and `script.js` accordingly

## 🔒 Privacy

- ✅ All data stored locally
- ✅ No internet connection required
- ✅ No personal information collected
- ✅ No tracking or analytics
- ✅ Your data is yours only

## 📱 Responsive Breakpoints

- **Desktop**: Full sidebar + multi-column layouts
- **Tablet** (1024px): Collapsible sidebar + adjusted grids
- **Mobile** (768px): Full-width, single column, mobile-optimized
- **Small Phone** (480px): Compact UI with essential features

## 🌐 Browser Support

- Chrome/Edge (Recommended)
- Firefox
- Safari
- Opera
- Any modern browser with ES6+ and LocalStorage support

## ⌨️ Keyboard Shortcuts

- Navigation through tab key
- Enter to submit forms
- Escape to close modals (recommended for future versions)

## 🎯 Study Tips

1. **Consistency**: Study at the same time every day
2. **Active Recall**: Try to answer questions without looking at notes
3. **Spaced Repetition**: Review topics multiple times
4. **Focus on Weak Areas**: Use AI recommendations
5. **Track Progress**: Monitor charts and accuracy trends
6. **Daily Goals**: Aim for 100% daily task completion
7. **Take Breaks**: Study in 45-minute sessions with 15-minute breaks

## 🐛 Known Limitations

- Exam date must be in the future
- Charts require Chart.js CDN (included in HTML)
- LocalStorage limit is ~5MB per domain
- Study time in statistics is simulated (for demo purposes)

## 🚀 Future Enhancements

Potential features for future versions:
- Cloud sync with Google Drive
- Spaced repetition algorithm (SM-2)
- Video tutorials for each topic
- Discussion forum for students
- Real-time collaboration features
- Mobile app (React Native)
- Community-contributed questions
- AI chatbot for doubt clearing
- Gamification with badges and achievements
- Integration with calendar apps

## 📝 License

This project is open-source and free to use for educational purposes.

## 💡 Tips for Best Results

1. **Start Easy**: Begin with easy topics to build confidence
2. **Read Explanations**: Always read MCQ explanations
3. **Use Study Planner**: Generate a plan based on exam date
4. **Track Streaks**: Maintain daily consistency
5. **Review Weak Areas**: Focus on topics with < 60% accuracy
6. **Progressive Difficulty**: Gradually increase difficulty level
7. **Regular Breaks**: Don't study more than 2 hours without a break

## 📞 Support

Having issues? Check:
1. Browser compatibility (use Chrome for best experience)
2. JavaScript is enabled
3. LocalStorage is not disabled
4. Clear browser cache if needed

## 🙏 Credits

Created with ❤️ for Computer Engineering students.

**Happy Learning! 🚀**

---

**Last Updated**: March 2026
