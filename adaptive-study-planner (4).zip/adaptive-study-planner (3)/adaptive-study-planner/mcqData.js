/* ==========================================
   MCQ DATA & SUBJECTS DATABASE
   ========================================== */

const MCQ_DATABASE = {
    Mathematics: {
        icon: '📐',
        topics: {
            'Calculus Fundamentals': {
                difficulty: 'medium',
                mcqs: [
                    {
                        question: 'What is the derivative of f(x) = 3x² + 2x + 1?',
                        options: ['6x + 2', '3x + 2', '6x² + 2x', '2x + 1'],
                        correct: 0,
                        explanation: 'Using the power rule: d/dx(x²) = 2x, d/dx(x) = 1. So f\'(x) = 6x + 2'
                    },
                    {
                        question: 'Find the integral of f(x) = 4x³',
                        options: ['x⁴ + C', '4x⁴ + C', 'x⁴/4 + C', '12x² + C'],
                        correct: 0,
                        explanation: 'Using integration rule: ∫xⁿ dx = xⁿ⁺¹/(n+1) + C. So ∫4x³ dx = x⁴ + C'
                    },
                    {
                        question: 'What is the limit of (x² - 1)/(x - 1) as x approaches 1?',
                        options: ['1', '2', '0', 'undefined'],
                        correct: 1,
                        explanation: 'Factor: (x² - 1)/(x - 1) = (x+1)(x-1)/(x-1) = x + 1. As x→1, the limit is 2'
                    },
                    {
                        question: 'Find the critical points of f(x) = x³ - 3x',
                        options: ['x = 1, x = -1', 'x = 0, x = 3', 'x = 1', 'x = 3'],
                        correct: 0,
                        explanation: 'f\'(x) = 3x² - 3 = 0. So 3(x² - 1) = 0, giving x = ±1'
                    },
                    {
                        question: 'What is the second derivative of f(x) = x⁴ - 2x²?',
                        options: ['4x³ - 4x', '12x² - 4', '12x² - 4x', '4x - 4'],
                        correct: 1,
                        explanation: 'f\'(x) = 4x³ - 4x. f\'\'(x) = 12x² - 4'
                    }
                ]
            },
            'Linear Algebra': {
                difficulty: 'hard',
                mcqs: [
                    {
                        question: 'What is the determinant of the matrix [[2, 1], [3, 4]]?',
                        options: ['5', '6', '-5', '11'],
                        correct: 0,
                        explanation: 'det = 2*4 - 1*3 = 8 - 3 = 5'
                    },
                    {
                        question: 'If A = [[1, 2], [3, 4]] and B = [[5, 6], [7, 8]], what is the first element of A*B?',
                        options: ['19', '23', '22', '14'],
                        correct: 0,
                        explanation: '(1*5 + 2*7) = 5 + 14 = 19'
                    },
                    {
                        question: 'What is the rank of the matrix [[1, 2], [2, 4]]?',
                        options: ['1', '2', '3', '0'],
                        correct: 0,
                        explanation: 'The second row is a multiple of the first, so rank = 1'
                    },
                    {
                        question: 'Find the eigenvalue of matrix [[3, 0], [0, 3]]',
                        options: ['3', '0', '6', '1'],
                        correct: 0,
                        explanation: 'This is a diagonal matrix. Eigenvalues are the diagonal elements: 3'
                    },
                    {
                        question: 'What is the inverse of matrix [[2, 1], [1, 1]]?',
                        options: ['[[1, -1], [-1, 2]]', '[[-1, 1], [1, -2]]', '[[1, -1], [-1, 2]]/det', 'Not invertible'],
                        correct: 0,
                        explanation: 'det = 2*1 - 1*1 = 1. A⁻¹ = (1/1)*[[1, -1], [-1, 2]] = [[1, -1], [-1, 2]]'
                    }
                ]
            },
            'Discrete Math': {
                difficulty: 'easy',
                mcqs: [
                    {
                        question: 'What is 2³ (2 to the power 3)?',
                        options: ['6', '8', '5', '9'],
                        correct: 1,
                        explanation: '2³ = 2 × 2 × 2 = 8'
                    },
                    {
                        question: 'How many bits are in 1 byte?',
                        options: ['4', '8', '16', '32'],
                        correct: 1,
                        explanation: '1 byte = 8 bits'
                    },
                    {
                        question: 'What is the truth value of (True AND False)?',
                        options: ['True', 'False', 'Undefined', 'Error'],
                        correct: 1,
                        explanation: 'AND operation: True AND False = False'
                    },
                    {
                        question: 'What is the complement of the set {1, 2, 3} in U = {1, 2, 3, 4, 5}?',
                        options: ['{1, 2, 3}', '{4, 5}', '{}', '{1, 2}'],
                        correct: 1,
                        explanation: 'The complement contains all elements in U that are not in {1, 2, 3}, which is {4, 5}'
                    },
                    {
                        question: 'How many permutations of {A, B, C} are there?',
                        options: ['3', '6', '9', '8'],
                        correct: 1,
                        explanation: 'Permutations = 3! = 3 × 2 × 1 = 6'
                    }
                ]
            }
        }
    },

    'Operating Systems': {
        icon: '🖥️',
        topics: {
            'Process Management': {
                difficulty: 'medium',
                mcqs: [
                    {
                        question: 'What is a process in an operating system?',
                        options: ['A task running on CPU', 'An instance of a program in execution', 'A thread of execution', 'Both B and C'],
                        correct: 1,
                        explanation: 'A process is an instance of a program in execution with its own memory, resources, and state'
                    },
                    {
                        question: 'Which scheduling algorithm is used in most modern systems?',
                        options: ['FCFS', 'SJF', 'Round Robin', 'Priority Scheduling'],
                        correct: 2,
                        explanation: 'Round Robin is the most commonly used in practical systems due to fair time distribution'
                    },
                    {
                        question: 'What is a deadlock?',
                        options: ['Process termination', 'Situation where processes wait indefinitely for resources', 'Memory overflow', 'CPU overload'],
                        correct: 1,
                        explanation: 'Deadlock occurs when processes are blocked and cannot proceed, waiting for resources held by each other'
                    },
                    {
                        question: 'What are the 4 necessary conditions for deadlock?',
                        options: ['Mutual exclusion, Hold and Wait, No Preemption, Circular Wait', 'CPU, Memory, Disk, I/O', 'Semaphore, Mutex, Lock, Monitor', 'Thread, Process, Kernel, User'],
                        correct: 0,
                        explanation: 'All 4 conditions must be present for deadlock: mutual exclusion, hold and wait, no preemption, and circular wait'
                    },
                    {
                        question: 'What is a thread?',
                        options: ['Lightweight process within a process', 'A core processing unit', 'Memory allocation unit', 'Disk I/O unit'],
                        correct: 0,
                        explanation: 'A thread is a lightweight process that shares memory with other threads in the same process'
                    }
                ]
            },
            'Memory Management': {
                difficulty: 'hard',
                mcqs: [
                    {
                        question: 'What is virtual memory?',
                        options: ['Memory stored in cloud', 'Technique using disk as extension of RAM', 'Encrypted memory', 'Cache memory'],
                        correct: 1,
                        explanation: 'Virtual memory uses disk storage as an extension of physical RAM to allow larger programs to run'
                    },
                    {
                        question: 'What is paging?',
                        options: ['Disk operation', 'Memory protection', 'Dividing memory into fixed-size blocks', 'CPU scheduling'],
                        correct: 2,
                        explanation: 'Paging divides virtual and physical memory into fixed-size blocks called pages and frames'
                    },
                    {
                        question: 'What causes a page fault?',
                        options: ['Page is in memory', 'Page is not in physical memory', 'Too many processes', 'CPU failure'],
                        correct: 1,
                        explanation: 'A page fault occurs when the program tries to access a page that is not currently in physical memory'
                    },
                    {
                        question: 'Which page replacement algorithm is optimal?',
                        options: ['FIFO', 'LRU', 'Optimal - replace page not used for longest time', 'MRU'],
                        correct: 2,
                        explanation: 'Optimal algorithm replaces the page that will not be used for the longest time in the future'
                    },
                    {
                        question: 'What is segmentation in memory management?',
                        options: ['Fixed size division', 'Variable size division of memory into logical segments', 'Disk partitioning', 'Cache organization'],
                        correct: 1,
                        explanation: 'Segmentation divides memory into variable-sized logical segments based on program structure'
                    }
                ]
            },
            'File Systems': {
                difficulty: 'easy',
                mcqs: [
                    {
                        question: 'What is a file system?',
                        options: ['Part of hardware', 'Software that manages file storage and retrieval', 'Database', 'Network protocol'],
                        correct: 1,
                        explanation: 'A file system is the method used by the OS to organize and manage files on storage devices'
                    },
                    {
                        question: 'What are common file systems?',
                        options: ['FAT, NTFS, ext4, APFS', 'CPU, RAM, GPU, SSD', 'HTML, CSS, JS, Python', 'TCP, UDP, FTP, HTTP'],
                        correct: 0,
                        explanation: 'FAT, NTFS, ext4, and APFS are popular file systems for different operating systems'
                    },
                    {
                        question: 'What is an inode?',
                        options: ['Storage device', 'Data structure storing file metadata', 'Network node', 'File content'],
                        correct: 1,
                        explanation: 'An inode is a data structure that stores metadata about a file (size, permissions, timestamps, etc.)'
                    },
                    {
                        question: 'What is a directory?',
                        options: ['A file', 'A container for files and other directories', 'A device', 'A process'],
                        correct: 1,
                        explanation: 'A directory is a special file that contains references to other files and directories'
                    },
                    {
                        question: 'What does ACL stand for?',
                        options: ['Automatic Control List', 'Access Control List', 'Advanced CPU Logic', 'Application Code Library'],
                        correct: 1,
                        explanation: 'ACL (Access Control List) specifies which users or system processes have access to objects'
                    }
                ]
            }
        }
    },

    'C Programming': {
        icon: '💻',
        topics: {
            'Pointers & Arrays': {
                difficulty: 'hard',
                mcqs: [
                    {
                        question: 'What is a pointer?',
                        options: ['A data type', 'A variable that stores memory address of another variable', 'A function', 'A comment'],
                        correct: 1,
                        explanation: 'A pointer is a variable that holds the memory address of another variable'
                    },
                    {
                        question: 'What is the output of: int *p; int x = 5; p = &x; printf("%d", *p);',
                        options: ['Address of x', '5', 'Error', 'Random value'],
                        correct: 1,
                        explanation: '*p dereferences the pointer, accessing the value at that address, which is 5'
                    },
                    {
                        question: 'What is array decay?',
                        options: ['Array gets corrupted', 'Array degrades in memory', 'Array name converts to pointer', 'Array size increases'],
                        correct: 2,
                        explanation: 'Array decay is when an array name is implicitly converted to a pointer to its first element'
                    },
                    {
                        question: 'How is a 2D array stored in memory?',
                        options: ['In 2D format', 'Row-wise (row major order)', 'Column-wise (column major order)', 'Randomly'],
                        correct: 1,
                        explanation: 'In C, 2D arrays are stored row-wise in memory (row major order)'
                    },
                    {
                        question: 'What is the difference between array and pointer?',
                        options: ['No difference', 'Array is fixed, pointer is variable', 'Pointer holds address, array stores elements', 'Both B and C'],
                        correct: 3,
                        explanation: 'Arrays are fixed-size collections stored contiguously; pointers are variables holding addresses'
                    }
                ]
            },
            'Strings & Functions': {
                difficulty: 'medium',
                mcqs: [
                    {
                        question: 'How are strings terminated in C?',
                        options: ['With a period', 'With null character (\\0)', 'With space', 'No termination needed'],
                        correct: 1,
                        explanation: 'Strings in C are terminated with a null character (\\0) to mark the end'
                    },
                    {
                        question: 'What is function overloading in C?',
                        options: ['Calling functions multiple times', 'Not supported in C', 'Multiple functions with same name', 'Creating nested functions'],
                        correct: 1,
                        explanation: 'C does not support function overloading; each function must have a unique name'
                    },
                    {
                        question: 'What is recursion?',
                        options: ['Using loops', 'Function calling itself', 'Calling different functions', 'Array iteration'],
                        correct: 1,
                        explanation: 'Recursion is when a function calls itself directly or indirectly'
                    },
                    {
                        question: 'What is the difference between local and global variables?',
                        options: ['No difference', 'Local is in function, global is outside', 'Global is faster', 'Local uses more memory'],
                        correct: 1,
                        explanation: 'Local variables are scoped to functions; global variables are accessible from anywhere'
                    },
                    {
                        question: 'What is static variable?',
                        options: ['Variable that cannot change', 'Variable with static memory allocation', 'Variable local to file or function', 'All of the above'],
                        correct: 3,
                        explanation: 'Static variables have fixed memory allocation and limited scope depending on declaration location'
                    }
                ]
            },
            'Structures & File I/O': {
                difficulty: 'easy',
                mcqs: [
                    {
                        question: 'What is a structure in C?',
                        options: ['A function', 'A user-defined data type grouping variables', 'A pointer', 'A library'],
                        correct: 1,
                        explanation: 'A structure is a composite data type that groups multiple variables of different types'
                    },
                    {
                        question: 'How to access structure members?',
                        options: ['Using dot operator for variables, arrow for pointers', 'Using arrow only', 'Using dot only', 'Using @ symbol'],
                        correct: 0,
                        explanation: 'Use dot (.) for direct access and arrow (->) for pointer access to structure members'
                    },
                    {
                        question: 'What does FILE do in C?',
                        options: ['Stores file content', 'Data structure for file operations', 'File extension', 'Network protocol'],
                        correct: 1,
                        explanation: 'FILE is a structure used to handle file operations in C'
                    },
                    {
                        question: 'Which function opens a file in C?',
                        options: ['file_open()', 'fopen()', 'open_file()', 'file_access()'],
                        correct: 1,
                        explanation: 'fopen() is the standard function to open files in C'
                    },
                    {
                        question: 'What is fwrite() used for?',
                        options: ['Write formatted output', 'Write binary data to file', 'Write text to console', 'Read from file'],
                        correct: 1,
                        explanation: 'fwrite() writes binary data to a file'
                    }
                ]
            }
        }
    },

    'Java': {
        icon: '☕',
        topics: {
            'OOP Concepts': {
                difficulty: 'medium',
                mcqs: [
                    {
                        question: 'What is encapsulation?',
                        options: ['Package designing', 'Hiding internal implementation', 'Memory allocation', 'Network communication'],
                        correct: 1,
                        explanation: 'Encapsulation is bundling data and methods while hiding internal implementation details'
                    },
                    {
                        question: 'What is inheritance?',
                        options: ['Getting variable values', 'A class acquiring properties of another class', 'Memory inheritance', 'Thread inheritance'],
                        correct: 1,
                        explanation: 'Inheritance allows a class to derive properties and methods from another class'
                    },
                    {
                        question: 'What is polymorphism?',
                        options: ['Multiple objects', 'One interface, multiple implementations', 'Multiple inheritance', 'Multiple threads'],
                        correct: 1,
                        explanation: 'Polymorphism means "many forms" - one interface can have multiple implementations'
                    },
                    {
                        question: 'What is abstraction?',
                        options: ['Abstract thinking', 'Hiding complexity, showing only necessary features', 'Class design', 'Memory management'],
                        correct: 1,
                        explanation: 'Abstraction hides complex implementation details and shows only essential features'
                    },
                    {
                        question: 'What is the difference between abstract class and interface?',
                        options: ['No difference', 'Abstract has methods, interface doesn\'t', 'Abstract can have state, interface cannot', 'Both can be instantiated'],
                        correct: 2,
                        explanation: 'Abstract classes can have state (variables) and constructors; interfaces can only have constants and method signatures'
                    }
                ]
            },
            'Collections & Generics': {
                difficulty: 'hard',
                mcqs: [
                    {
                        question: 'What is the difference between List and Set?',
                        options: ['No difference', 'List allows duplicates, Set does not', 'Set is faster', 'List requires sorting'],
                        correct: 1,
                        explanation: 'List maintains insertion order and allows duplicates; Set does not allow duplicates'
                    },
                    {
                        question: 'What is HashMap?',
                        options: ['Array of maps', 'Hash-based key-value storage', 'Sorted map', 'Thread-safe map'],
                        correct: 1,
                        explanation: 'HashMap is a hash-based implementation of the Map interface for key-value pair storage'
                    },
                    {
                        question: 'What is the time complexity of HashMap get()?',
                        options: ['O(n)', 'O(log n)', 'O(1)', 'O(n²)'],
                        correct: 2,
                        explanation: 'HashMap provides O(1) average time complexity for get() operation'
                    },
                    {
                        question: 'What is a generic in Java?',
                        options: ['General term', 'Type-safe way to use collections', 'Network protocol', 'Memory allocation'],
                        correct: 1,
                        explanation: 'Generics provide type safety and eliminate ClassCastException by using parameterized types'
                    },
                    {
                        question: 'What is the difference between checked and unchecked exceptions?',
                        options: ['No difference', 'Checked must be caught, unchecked need not', 'Unchecked are less severe', 'Both must be caught'],
                        correct: 1,
                        explanation: 'Checked exceptions must be caught/declared; unchecked (runtime) exceptions do not require explicit handling'
                    }
                ]
            },
            'Multithreading': {
                difficulty: 'easy',
                mcqs: [
                    {
                        question: 'How to create a thread in Java?',
                        options: ['Extend Thread class or implement Runnable', 'Create new object', 'Use main method', 'Call System.thread()'],
                        correct: 0,
                        explanation: 'In Java, create threads by extending Thread class or implementing Runnable interface'
                    },
                    {
                        question: 'What is the difference between start() and run()?',
                        options: ['No difference', 'start() creates new thread, run() executes in current thread', 'run() is faster', 'start() is deprecated'],
                        correct: 1,
                        explanation: 'start() creates a new thread; run() executes in the current thread without creating a new one'
                    },
                    {
                        question: 'What is synchronization in Java?',
                        options: ['Data transfer', 'Mechanism to control access to shared resources', 'Network protocol', 'Memory allocation'],
                        correct: 1,
                        explanation: 'Synchronization prevents multiple threads from accessing the same resource simultaneously'
                    },
                    {
                        question: 'What is a deadlock in Java?',
                        options: ['Program crash', 'Threads waiting indefinitely for each other', 'Memory error', 'CPU overload'],
                        correct: 1,
                        explanation: 'Deadlock occurs when threads are blocked, each waiting for a resource held by another'
                    },
                    {
                        question: 'What does volatile keyword do?',
                        options: ['Makes variable unstable', 'Ensures visibility of variable changes across threads', 'Increases speed', 'Encrypts variable'],
                        correct: 1,
                        explanation: 'volatile ensures that changes to a variable are immediately visible to all threads'
                    }
                ]
            }
        }
    }
};

// Initialize exam date default
document.addEventListener('DOMContentLoaded', function() {
    const examDateInput = document.getElementById('examDate');
    if (examDateInput) {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 30);
        const year = tomorrow.getFullYear();
        const month = String(tomorrow.getMonth() + 1).padStart(2, '0');
        const day = String(tomorrow.getDate()).padStart(2, '0');
        examDateInput.min = new Date().toISOString().split('T')[0];
        examDateInput.value = `${year}-${month}-${day}`;
    }
});
