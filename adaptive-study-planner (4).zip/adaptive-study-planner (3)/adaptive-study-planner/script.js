const ENGINEERING_DATA = {
    computer: {
        label: 'Computer Engineering',
        semesters: {
            1: {
                subjects: [
                    { name: 'Engineering Mathematics I', topics: ['Matrices', 'Differentiation', 'Integration', 'Complex Numbers', 'Applications of Calculus'] },
                    { name: 'Basic Programming', topics: ['Algorithms', 'Flowcharts', 'C Basics', 'Loops', 'Functions'] },
                    { name: 'Engineering Physics', topics: ['Waves', 'Optics', 'Semiconductors', 'Laser', 'Interference'] },
                    { name: 'Engineering Graphics', topics: ['Projection', 'Orthographic Views', 'Sectional Views', 'Dimensioning', 'Isometric Drawing'] },
                    { name: 'Communication Skills', topics: ['Grammar', 'Technical Writing', 'Presentation Skills', 'Reading Skills', 'Group Discussion'] }
                ]
            },
            2: {
                subjects: [
                    { name: 'Engineering Mathematics II', topics: ['Differential Equations', 'Laplace Transform', 'Fourier Series', 'Probability', 'Statistics'] },
                    { name: 'Data Structures', topics: ['Arrays', 'Linked Lists', 'Stacks', 'Queues', 'Trees'] },
                    { name: 'Digital Logic Design', topics: ['Boolean Algebra', 'Logic Gates', 'Combinational Circuits', 'Sequential Circuits', 'K Maps'] },
                    { name: 'Object Oriented Programming', topics: ['Classes', 'Inheritance', 'Polymorphism', 'Abstraction', 'Exception Handling'] },
                    { name: 'Environmental Studies', topics: ['Ecosystems', 'Pollution', 'Sustainability', 'Natural Resources', 'Climate Change'] }
                ]
            },
            3: {
                subjects: [
                    { name: 'Database Management Systems', topics: ['ER Model', 'Normalization', 'SQL', 'Transactions', 'Indexing'] },
                    { name: 'Computer Organization', topics: ['CPU', 'Memory Hierarchy', 'Instruction Cycle', 'I/O Organization', 'Pipelining'] },
                    { name: 'Discrete Mathematics', topics: ['Logic', 'Relations', 'Graphs', 'Combinatorics', 'Recurrence Relations'] },
                    { name: 'Java Programming', topics: ['JVM', 'Collections', 'Multithreading', 'File Handling', 'Interfaces'] },
                    { name: 'Operating Systems', topics: ['Processes', 'Threads', 'Scheduling', 'Deadlocks', 'Memory Management'] }
                ]
            },
            4: {
                subjects: [
                    { name: 'CT (Computational Theory)', topics: ['Finite Automata', 'Regular Expressions', 'Context-Free Grammar', 'Turing Machines', 'Decidability'] },
                    { name: 'OS (Operating System)', topics: ['Process Management', 'Scheduling Algorithms', 'Memory Management', 'Deadlocks', 'File Systems'] },
                    { name: 'DBMS (Database Management System)', topics: ['ER Model', 'SQL Queries', 'Normalization', 'Transactions', 'Indexing'] },
                    { name: 'DT (Design Thinking)', topics: ['Empathy Mapping', 'Problem Definition', 'Ideation', 'Prototyping', 'Testing'] },
                    { name: 'IWT (Introduction to Web Technology)', topics: ['HTML & CSS', 'JavaScript', 'Frontend Frameworks', 'Backend Basics', 'APIs'] }
                ]
            },
            5: {
                subjects: [
                    { name: 'Web Technology', topics: ['HTML CSS', 'JavaScript', 'DOM', 'APIs', 'Responsive Design'] },
                    { name: 'Compiler Design', topics: ['Lexical Analysis', 'Parsing', 'Syntax Trees', 'Code Generation', 'Optimization'] },
                    { name: 'Machine Learning', topics: ['Regression', 'Classification', 'Clustering', 'Model Evaluation', 'Feature Engineering'] },
                    { name: 'Information Security', topics: ['Cryptography', 'Authentication', 'Access Control', 'Network Attacks', 'Security Policies'] },
                    { name: 'Mobile Computing', topics: ['Wireless Networks', 'Mobile OS', 'Location Management', 'Applications', 'Security'] }
                ]
            },
            6: {
                subjects: [
                    { name: 'Artificial Intelligence', topics: ['Search Techniques', 'Knowledge Representation', 'Reasoning', 'Expert Systems', 'Planning'] },
                    { name: 'Cloud Computing', topics: ['Virtualization', 'Cloud Models', 'Deployment Models', 'Containers', 'Scalability'] },
                    { name: 'Data Mining', topics: ['Preprocessing', 'Association Rules', 'Classification', 'Clustering', 'Pattern Discovery'] },
                    { name: 'Internet of Things', topics: ['Sensors', 'Microcontrollers', 'Protocols', 'IoT Architecture', 'Applications'] },
                    { name: 'Distributed Systems', topics: ['Distributed Models', 'RPC', 'Synchronization', 'Fault Tolerance', 'Consistency'] }
                ]
            },
            7: {
                subjects: [
                    { name: 'Deep Learning', topics: ['Neural Networks', 'CNN', 'RNN', 'Training', 'Optimization'] },
                    { name: 'Big Data Analytics', topics: ['Hadoop', 'Spark', 'MapReduce', 'NoSQL', 'Streaming Data'] },
                    { name: 'Cyber Security', topics: ['Threat Models', 'Malware', 'Incident Response', 'Vulnerability Assessment', 'Ethical Hacking'] },
                    { name: 'DevOps', topics: ['CI CD', 'Version Control', 'Containers', 'Monitoring', 'Automation'] },
                    { name: 'Project Management', topics: ['Planning', 'Scheduling', 'Risk Management', 'Resource Allocation', 'Project Tracking'] }
                ]
            },
            8: {
                subjects: [
                    { name: 'Capstone Project', topics: ['Problem Definition', 'Architecture', 'Implementation', 'Testing', 'Presentation'] },
                    { name: 'Professional Ethics', topics: ['Ethical Principles', 'Case Studies', 'Responsibility', 'Standards', 'Decision Making'] },
                    { name: 'Emerging Technologies', topics: ['Blockchain', 'AR VR', 'Quantum Computing', 'Edge AI', 'Digital Twins'] },
                    { name: 'Entrepreneurship', topics: ['Business Model', 'Startup Planning', 'Funding', 'Marketing', 'Pitching'] },
                    { name: 'Industry Internship Review', topics: ['Documentation', 'Learning Outcomes', 'Technical Review', 'Reporting', 'Viva Preparation'] }
                ]
            }
        }
    },
    civil: {
        label: 'Civil Engineering',
        semesters: {
            1: { subjects: [
                { name: 'Engineering Mathematics I', topics: ['Matrices', 'Limits', 'Differentiation', 'Integration', 'Applications'] },
                { name: 'Engineering Mechanics', topics: ['Forces', 'Equilibrium', 'Friction', 'Centroid', 'Moments'] },
                { name: 'Engineering Drawing', topics: ['Lines', 'Planes', 'Projection', 'Sections', 'Dimensioning'] },
                { name: 'Construction Materials', topics: ['Bricks', 'Cement', 'Aggregates', 'Steel', 'Timber'] },
                { name: 'Communication Skills', topics: ['Writing', 'Presentation', 'Listening', 'Reading', 'Group Discussion'] }
            ]},
            2: { subjects: [
                { name: 'Engineering Mathematics II', topics: ['Differential Equations', 'Probability', 'Statistics', 'Transforms', 'Series'] },
                { name: 'Surveying I', topics: ['Chain Survey', 'Compass Survey', 'Levelling', 'Theodolite', 'Contouring'] },
                { name: 'Fluid Mechanics', topics: ['Properties of Fluids', 'Pressure', 'Flow Measurement', 'Bernoulli Equation', 'Hydrostatics'] },
                { name: 'Building Construction', topics: ['Foundations', 'Masonry', 'Roofing', 'Flooring', 'Finishing'] },
                { name: 'Environmental Science', topics: ['Ecosystem', 'Pollution', 'Waste', 'Sustainability', 'Water Conservation'] }
            ]},
            3: { subjects: [
                { name: 'Strength of Materials', topics: ['Stress', 'Strain', 'Bending', 'Torsion', 'Columns'] },
                { name: 'Surveying II', topics: ['Tacheometry', 'Curves', 'EDM', 'Plane Table', 'Traversing'] },
                { name: 'Concrete Technology', topics: ['Cement Chemistry', 'Mix Design', 'Fresh Concrete', 'Hardened Concrete', 'Admixtures'] },
                { name: 'Structural Analysis I', topics: ['Beams', 'Trusses', 'Deflection', 'Influence Line', 'Energy Methods'] },
                { name: 'Hydraulics', topics: ['Open Channel Flow', 'Pipes', 'Pumps', 'Turbines', 'Hydraulic Machines'] }
            ]},
            4: { subjects: [
                { name: 'Geotechnical Engineering', topics: ['Soil Formation', 'Soil Classification', 'Compaction', 'Permeability', 'Consolidation'] },
                { name: 'Transportation Engineering', topics: ['Highway Planning', 'Geometric Design', 'Pavements', 'Traffic Engineering', 'Airport Basics'] },
                { name: 'Structural Analysis II', topics: ['Indeterminate Structures', 'Slope Deflection', 'Moment Distribution', 'Matrix Method', 'Arches'] },
                { name: 'Water Supply Engineering', topics: ['Demand Estimation', 'Sources', 'Treatment', 'Distribution', 'Pumping'] },
                { name: 'Construction Planning', topics: ['Scheduling', 'CPM', 'PERT', 'Resource Planning', 'Site Management'] }
            ]},
            5: { subjects: [
                { name: 'Design of RCC Structures', topics: ['Limit State Method', 'Beams', 'Slabs', 'Columns', 'Footings'] },
                { name: 'Environmental Engineering', topics: ['Wastewater', 'Sewerage', 'Treatment Units', 'Solid Waste', 'Air Pollution'] },
                { name: 'Irrigation Engineering', topics: ['Water Requirement', 'Canals', 'Reservoirs', 'Diversion Head Works', 'Drainage'] },
                { name: 'Estimation and Costing', topics: ['Quantity Surveying', 'Rate Analysis', 'Valuation', 'Specifications', 'Contracts'] },
                { name: 'Steel Structures', topics: ['Tension Members', 'Compression Members', 'Connections', 'Beams', 'Columns'] }
            ]},
            6: { subjects: [
                { name: 'Foundation Engineering', topics: ['Bearing Capacity', 'Shallow Foundations', 'Deep Foundations', 'Settlement', 'Pile Design'] },
                { name: 'Bridge Engineering', topics: ['Bridge Components', 'Loads', 'Bearings', 'Deck Design', 'Maintenance'] },
                { name: 'Railway and Tunnel Engineering', topics: ['Track Geometry', 'Sleepers', 'Ballast', 'Tunnelling Methods', 'Ventilation'] },
                { name: 'Construction Management', topics: ['Project Scheduling', 'Quality Control', 'Safety', 'Contracts', 'Procurement'] },
                { name: 'Advanced Surveying', topics: ['GPS', 'GIS', 'Remote Sensing', 'Photogrammetry', 'Total Station'] }
            ]},
            7: { subjects: [
                { name: 'Advanced Concrete Design', topics: ['Prestressed Concrete', 'Water Tanks', 'Staircases', 'Retaining Walls', 'Earthquake Resistant Design'] },
                { name: 'Urban Planning', topics: ['Planning Principles', 'Land Use', 'Housing', 'Transportation Planning', 'Urban Services'] },
                { name: 'Disaster Management', topics: ['Hazards', 'Mitigation', 'Preparedness', 'Response', 'Recovery'] },
                { name: 'Quantity Surveying', topics: ['BOQ', 'Measurement Rules', 'Tendering', 'Billing', 'Cost Control'] },
                { name: 'Elective Civil Systems', topics: ['Green Buildings', 'Smart Cities', 'Water Reuse', 'Structural Health Monitoring', 'Sustainable Materials'] }
            ]},
            8: { subjects: [
                { name: 'Capstone Project', topics: ['Problem Statement', 'Design', 'Analysis', 'Implementation', 'Presentation'] },
                { name: 'Professional Practice', topics: ['Ethics', 'Codes', 'Tenders', 'Consultancy', 'Documentation'] },
                { name: 'Infrastructure Engineering', topics: ['Road Assets', 'Water Systems', 'Urban Infrastructure', 'Maintenance', 'Lifecycle Planning'] },
                { name: 'Entrepreneurship', topics: ['Business Plan', 'Finance', 'Marketing', 'Leadership', 'Pitching'] },
                { name: 'Internship Review', topics: ['Field Diary', 'Site Observation', 'Reporting', 'Technical Review', 'Viva'] }
            ]}
        }
    },
    mechanical: {
        label: 'Mechanical Engineering',
        semesters: {
            1: { subjects: [
                { name: 'Engineering Mathematics I', topics: ['Matrices', 'Calculus', 'Differentiation', 'Integration', 'Applications'] },
                { name: 'Basic Mechanical Engineering', topics: ['Thermodynamics Basics', 'IC Engines', 'Power Transmission', 'Manufacturing Overview', 'Mechanisms'] },
                { name: 'Engineering Graphics', topics: ['Projection', 'Sections', 'Orthographic Drawing', 'Isometric Views', 'Dimensioning'] },
                { name: 'Engineering Physics', topics: ['Heat', 'Optics', 'Material Science', 'Semiconductors', 'Lasers'] },
                { name: 'Workshop Practice', topics: ['Fitting', 'Welding', 'Machining', 'Casting', 'Carpentry'] }
            ]},
            2: { subjects: [
                { name: 'Engineering Mathematics II', topics: ['Differential Equations', 'Probability', 'Laplace Transform', 'Statistics', 'Series'] },
                { name: 'Engineering Mechanics', topics: ['Statics', 'Dynamics', 'Friction', 'Work Energy', 'Impulse Momentum'] },
                { name: 'Material Science', topics: ['Crystal Structure', 'Heat Treatment', 'Phase Diagram', 'Ferrous Metals', 'Polymers'] },
                { name: 'Thermodynamics', topics: ['Laws of Thermodynamics', 'Entropy', 'Cycles', 'Properties of Steam', 'Heat Engines'] },
                { name: 'Manufacturing Processes', topics: ['Casting', 'Forming', 'Machining', 'Joining', 'Powder Metallurgy'] }
            ]},
            3: { subjects: [
                { name: 'Strength of Materials', topics: ['Stress Strain', 'Bending', 'Torsion', 'Deflection', 'Columns'] },
                { name: 'Fluid Mechanics', topics: ['Fluid Properties', 'Hydrostatics', 'Flow Kinematics', 'Bernoulli', 'Boundary Layer'] },
                { name: 'Kinematics of Machines', topics: ['Mechanisms', 'Velocity Analysis', 'Acceleration Analysis', 'Gears', 'Cams'] },
                { name: 'Machine Drawing', topics: ['Assembly Drawing', 'Part Drawing', 'Fits', 'Tolerances', 'Sections'] },
                { name: 'Electrical Machines', topics: ['Transformers', 'DC Machines', 'Induction Motor', 'Synchronous Machines', 'Applications'] }
            ]},
            4: { subjects: [
                { name: 'Theory of Machines', topics: ['Governors', 'Gyroscope', 'Balancing', 'Vibration', 'Flywheel'] },
                { name: 'Heat Transfer', topics: ['Conduction', 'Convection', 'Radiation', 'Heat Exchangers', 'Boiling'] },
                { name: 'Machine Design I', topics: ['Design Process', 'Failure Theories', 'Shafts', 'Keys', 'Couplings'] },
                { name: 'Metrology and Instrumentation', topics: ['Measurement Standards', 'Comparators', 'Surface Roughness', 'Sensors', 'Calibration'] },
                { name: 'Production Technology', topics: ['Machine Tools', 'Cutting Tool Geometry', 'Jigs and Fixtures', 'CNC Basics', 'Economics'] }
            ]},
            5: { subjects: [
                { name: 'Internal Combustion Engines', topics: ['Engine Cycles', 'Fuel Systems', 'Combustion', 'Performance Testing', 'Emission Control'] },
                { name: 'Machine Design II', topics: ['Bearings', 'Springs', 'Gears', 'Brakes', 'Clutches'] },
                { name: 'Dynamics of Machinery', topics: ['Inertia Forces', 'Turning Moment', 'Cams', 'Vibrations', 'Balancing'] },
                { name: 'Industrial Engineering', topics: ['Work Study', 'Plant Layout', 'Inventory Control', 'Operations Research', 'Ergonomics'] },
                { name: 'Refrigeration and Air Conditioning', topics: ['Refrigerants', 'Vapor Compression', 'Psychrometry', 'Air Conditioning Systems', 'Load Calculation'] }
            ]},
            6: { subjects: [
                { name: 'Finite Element Methods', topics: ['Discretization', 'Element Types', 'Shape Functions', 'Assembly', 'Applications'] },
                { name: 'CAD CAM', topics: ['Geometric Modeling', 'Drafting', 'NC Programming', 'Tool Paths', 'Automation'] },
                { name: 'Power Plant Engineering', topics: ['Steam Power Plant', 'Gas Turbine Plant', 'Nuclear Plant', 'Hydro Plant', 'Economics'] },
                { name: 'Automobile Engineering', topics: ['Transmission', 'Suspension', 'Braking Systems', 'Steering', 'Vehicle Dynamics'] },
                { name: 'Quality Engineering', topics: ['Statistical Quality Control', 'Six Sigma', 'Reliability', 'Inspection', 'Standards'] }
            ]},
            7: { subjects: [
                { name: 'Robotics', topics: ['Robot Anatomy', 'Kinematics', 'Actuators', 'Sensors', 'Applications'] },
                { name: 'Renewable Energy Systems', topics: ['Solar', 'Wind', 'Biomass', 'Hydrogen', 'Energy Storage'] },
                { name: 'Advanced Manufacturing', topics: ['3D Printing', 'Laser Machining', 'Non Traditional Methods', 'Flexible Manufacturing', 'Micro Manufacturing'] },
                { name: 'Maintenance Engineering', topics: ['Preventive Maintenance', 'Predictive Maintenance', 'TPM', 'Reliability', 'Maintenance Planning'] },
                { name: 'Project Management', topics: ['Planning', 'Costing', 'Scheduling', 'Risk', 'Execution'] }
            ]},
            8: { subjects: [
                { name: 'Capstone Project', topics: ['Concept Selection', 'Design', 'Analysis', 'Fabrication', 'Presentation'] },
                { name: 'Professional Ethics', topics: ['Ethics', 'Safety', 'Standards', 'Responsibility', 'Decision Making'] },
                { name: 'Entrepreneurship', topics: ['Business Models', 'Manufacturing Startup', 'Finance', 'Marketing', 'Operations'] },
                { name: 'Industry Internship Review', topics: ['Documentation', 'Production Study', 'Reporting', 'Technical Review', 'Viva'] },
                { name: 'Emerging Mechanical Systems', topics: ['Mechatronics', 'Smart Manufacturing', 'Digital Twin', 'Green Mobility', 'Advanced Materials'] }
            ]}
        }
    },
    electrical: {
        label: 'Electrical Engineering',
        semesters: {
            1: { subjects: [
                { name: 'Engineering Mathematics I', topics: ['Matrices', 'Calculus', 'Differentiation', 'Integration', 'Applications'] },
                { name: 'Basic Electrical Engineering', topics: ['Circuit Elements', 'Ohms Law', 'Network Theorems', 'AC Basics', 'Power'] },
                { name: 'Engineering Physics', topics: ['Semiconductors', 'Optics', 'Waves', 'Laser', 'Material Properties'] },
                { name: 'Engineering Drawing', topics: ['Projection', 'Orthographic Drawing', 'Sections', 'Dimensioning', 'Sketching'] },
                { name: 'Communication Skills', topics: ['Writing', 'Speaking', 'Reading', 'Listening', 'Presentation'] }
            ]},
            2: { subjects: [
                { name: 'Engineering Mathematics II', topics: ['Differential Equations', 'Laplace Transform', 'Probability', 'Statistics', 'Fourier Series'] },
                { name: 'Network Analysis', topics: ['Mesh Analysis', 'Nodal Analysis', 'Thevenin', 'Transient Response', 'Resonance'] },
                { name: 'Electronic Devices', topics: ['Diodes', 'Transistors', 'Rectifiers', 'Amplifiers', 'Oscillators'] },
                { name: 'Electrical Machines I', topics: ['Transformers', 'DC Generators', 'DC Motors', 'Losses', 'Testing'] },
                { name: 'Environmental Studies', topics: ['Sustainability', 'Pollution', 'Energy Conservation', 'Resources', 'Climate Change'] }
            ]},
            3: { subjects: [
                { name: 'Electrical Machines II', topics: ['Induction Motor', 'Synchronous Machine', 'Special Machines', 'Starting Methods', 'Characteristics'] },
                { name: 'Analog Circuits', topics: ['BJT Amplifiers', 'FET Amplifiers', 'Feedback', 'Oscillators', 'Power Amplifiers'] },
                { name: 'Signals and Systems', topics: ['Continuous Signals', 'Discrete Signals', 'LTI Systems', 'Fourier Transform', 'Sampling'] },
                { name: 'Measurements and Instrumentation', topics: ['Instruments', 'Errors', 'Bridges', 'Sensors', 'Transducers'] },
                { name: 'Electromagnetic Fields', topics: ['Electric Field', 'Magnetic Field', 'Maxwell Equations', 'Wave Propagation', 'Boundary Conditions'] }
            ]},
            4: { subjects: [
                { name: 'Power Systems I', topics: ['Generation', 'Transmission', 'Distribution', 'Load Curves', 'Tariffs'] },
                { name: 'Control Systems', topics: ['Transfer Function', 'Block Diagram', 'Time Response', 'Stability', 'Controllers'] },
                { name: 'Power Electronics', topics: ['SCR', 'Choppers', 'Inverters', 'Converters', 'Gate Drives'] },
                { name: 'Digital Electronics', topics: ['Logic Gates', 'Flip Flops', 'Counters', 'Registers', 'ADC DAC'] },
                { name: 'Microprocessors', topics: ['Architecture', 'Instruction Set', 'Assembly Programming', 'Interfacing', 'Interrupts'] }
            ]},
            5: { subjects: [
                { name: 'Power Systems II', topics: ['Fault Analysis', 'Protection', 'Relays', 'Switchgear', 'Stability'] },
                { name: 'Electrical Drives', topics: ['Drive Characteristics', 'DC Drives', 'AC Drives', 'Motor Control', 'Applications'] },
                { name: 'Utilization of Electrical Energy', topics: ['Electric Heating', 'Lighting', 'Traction', 'Welding', 'Tariff Applications'] },
                { name: 'Renewable Energy', topics: ['Solar', 'Wind', 'Fuel Cells', 'Storage', 'Grid Integration'] },
                { name: 'Linear Integrated Circuits', topics: ['Op Amps', 'Timers', 'Filters', 'Regulators', 'Applications'] }
            ]},
            6: { subjects: [
                { name: 'High Voltage Engineering', topics: ['Breakdown Mechanisms', 'Generation of High Voltage', 'Testing', 'Insulation', 'Surge Protection'] },
                { name: 'Switchgear and Protection', topics: ['Circuit Breakers', 'Relays', 'Protection Schemes', 'Arc Interruption', 'Coordination'] },
                { name: 'Embedded Systems', topics: ['Microcontrollers', 'Interfaces', 'Timers', 'Serial Communication', 'Applications'] },
                { name: 'Electrical Machine Design', topics: ['Magnetic Circuits', 'Transformer Design', 'Motor Design', 'Thermal Considerations', 'Optimization'] },
                { name: 'Industrial Automation', topics: ['PLC', 'SCADA', 'Sensors', 'Actuators', 'Control Logic'] }
            ]},
            7: { subjects: [
                { name: 'Smart Grids', topics: ['Grid Modernization', 'AMI', 'Demand Response', 'Distributed Generation', 'Power Quality'] },
                { name: 'FACTS and HVDC', topics: ['HVDC Basics', 'Converters', 'FACTS Devices', 'Power Flow Control', 'Applications'] },
                { name: 'Electric Vehicles', topics: ['Battery Systems', 'Traction Motors', 'Charging Infrastructure', 'Power Electronics', 'Vehicle Control'] },
                { name: 'Energy Management', topics: ['Auditing', 'Conservation', 'Monitoring', 'Optimization', 'Standards'] },
                { name: 'Project Management', topics: ['Planning', 'Costing', 'Scheduling', 'Risk', 'Execution'] }
            ]},
            8: { subjects: [
                { name: 'Capstone Project', topics: ['Problem Definition', 'Design', 'Implementation', 'Testing', 'Presentation'] },
                { name: 'Professional Ethics', topics: ['Ethics', 'Safety', 'Codes', 'Responsibility', 'Decision Making'] },
                { name: 'Entrepreneurship', topics: ['Business Model', 'Finance', 'Marketing', 'Pitching', 'Scaling'] },
                { name: 'Industry Internship Review', topics: ['Documentation', 'Technical Review', 'Reporting', 'Learning Outcomes', 'Viva'] },
                { name: 'Emerging Electrical Systems', topics: ['Microgrids', 'Grid Storage', 'Digital Substations', 'AI in Power Systems', 'Wide Area Monitoring'] }
            ]}
        }
    }
};

const COMPUTER_SEM4_MCQ_BANK = {
    'CT (Computational Theory)': {
        'Finite Automata': [
            { question: 'A DFA has how many start states?', options: ['0', '1', 'Many', 'Infinite'], correct: 1 },
            { question: 'DFA recognizes:', options: ['CFG', 'Regular languages', 'All', 'None'], correct: 1 },
            { question: 'DFA transition depends on:', options: ['Memory', 'Stack', 'Input and state', 'Output'], correct: 2 },
            { question: 'DFA cannot have:', options: ['States', 'Final states', 'epsilon-transitions', 'Alphabet'], correct: 2 },
            { question: 'DFA is:', options: ['Deterministic', 'Random', 'Infinite', 'Recursive'], correct: 0 }
        ],
        'Regular Expressions': [
            { question: 'Regular expressions are used for:', options: ['Parsing', 'Pattern matching', 'Execution', 'Storage'], correct: 1 },
            { question: "In regular expressions, '|' means:", options: ['AND', 'OR', 'NOT', 'LOOP'], correct: 1 },
            { question: "In regular expressions, '*' means:", options: ['One', 'Many', 'Zero or more', 'None'], correct: 2 },
            { question: 'Regular expressions define:', options: ['CFG', 'Regular language', 'Turing machine', 'None'], correct: 1 },
            { question: 'epsilon means:', options: ['Space', 'Empty string', 'Error', 'State'], correct: 1 }
        ],
        'Context-Free Grammar': [
            { question: 'CFG is mainly used in:', options: ['Lexical analysis', 'Syntax analysis', 'Execution', 'Debugging'], correct: 1 },
            { question: 'CFG generates:', options: ['Regular languages', 'Context-free languages', 'All languages', 'None'], correct: 1 },
            { question: 'The start symbol in CFG is a:', options: ['Terminal', 'Variable', 'Constant', 'Function'], correct: 1 },
            { question: 'A production rule in CFG typically has the form:', options: ['A -> alpha', 'A = B', 'A + B', 'A / B'], correct: 0 },
            { question: 'CFG consists of:', options: ['States', 'Variables and terminals', 'Memory', 'Stack'], correct: 1 }
        ],
        'Turing Machines': [
            { question: 'A Turing machine has:', options: ['Infinite tape', 'Stack', 'No memory', 'Fixed memory'], correct: 0 },
            { question: 'Turing machines are used for:', options: ['Networking', 'Computation', 'Graphics', 'Storage'], correct: 1 },
            { question: 'The tape head of a Turing machine can move:', options: ['Left', 'Right', 'Both', 'None'], correct: 2 },
            { question: 'A Turing machine is more powerful than:', options: ['DFA', 'PDA', 'Both', 'None'], correct: 2 },
            { question: 'Turing machines recognize:', options: ['Regular languages', 'CFG only', 'Computable languages', 'None'], correct: 2 }
        ],
        'Decidability': [
            { question: 'Decidable problems are those for which:', options: ['No solution exists', 'An algorithm exists', 'They always loop', 'They always error'], correct: 1 },
            { question: 'The halting problem is:', options: ['Easy', 'Decidable', 'Undecidable', 'Linear'], correct: 2 },
            { question: 'Undecidable means:', options: ['Solvable', 'Not solvable by an algorithm in general', 'Easy', 'Finite'], correct: 1 },
            { question: 'Decidable problems eventually:', options: ['Halt', 'Loop forever', 'Crash', 'Skip'], correct: 0 },
            { question: 'An example of an undecidable problem is:', options: ['Sorting', 'Searching', 'Halting problem', 'Addition'], correct: 2 }
        ]
    },
    'OS (Operating System)': {
        'Process Management': [
            { question: 'A process is:', options: ['Program execution', 'File', 'Memory', 'CPU'], correct: 0 },
            { question: 'PCB stands for:', options: ['Process Control Block', 'Program Block', 'Control Base', 'None'], correct: 0 },
            { question: 'Process states include:', options: ['Ready', 'Running', 'Waiting', 'All'], correct: 3 },
            { question: 'Context switching mainly means:', options: ['Memory change', 'CPU switch', 'Process switch', 'None'], correct: 1 },
            { question: 'A thread is:', options: ['Heavyweight', 'Lightweight', 'Memory', 'Program'], correct: 1 }
        ],
        'Scheduling Algorithms': [
            { question: 'FCFS stands for:', options: ['First Come First Serve', 'Fast CPU First System', 'File Control First Scan', 'None'], correct: 0 },
            { question: 'SJF is a type of:', options: ['Scheduling', 'Memory', 'File', 'None'], correct: 0 },
            { question: 'Round Robin scheduling uses:', options: ['Priority only', 'Time quantum', 'Memory pages', 'None'], correct: 1 },
            { question: 'The goal of scheduling is to maximize:', options: ['CPU utilization', 'Delay', 'Crash rate', 'Wait time'], correct: 0 },
            { question: 'Preemptive scheduling means:', options: ['No switch', 'Force switch', 'Slow switch', 'None'], correct: 1 }
        ],
        'Memory Management': [
            { question: 'Paging uses:', options: ['Pages', 'Files', 'Threads', 'None'], correct: 0 },
            { question: 'Fragmentation is:', options: ['Memory waste', 'CPU use', 'Speed', 'None'], correct: 0 },
            { question: 'Virtual memory is primarily:', options: ['Real memory only', 'Disk-based memory extension', 'CPU cache', 'None'], correct: 1 },
            { question: 'A page fault occurs when:', options: ['There is an error', 'A page is missing from main memory', 'System crashes', 'None'], correct: 1 },
            { question: 'Memory allocation types can be:', options: ['Fixed', 'Dynamic', 'Both', 'None'], correct: 2 }
        ],
        'Deadlocks': [
            { question: 'Deadlock means processes are:', options: ['Free', 'Blocked', 'Fast', 'None'], correct: 1 },
            { question: 'Deadlock conditions include:', options: ['Mutual exclusion', 'Hold and wait', 'No preemption', 'All'], correct: 3 },
            { question: 'Deadlock avoidance commonly uses:', options: ["Banker's algorithm", 'FIFO', 'LRU', 'None'], correct: 0 },
            { question: 'Deadlock detection often uses a:', options: ['Graph', 'Tree', 'List', 'None'], correct: 0 },
            { question: 'Deadlock prevention removes at least one:', options: ['Condition', 'CPU', 'Memory', 'None'], correct: 0 }
        ],
        'File Systems': [
            { question: 'A file is a:', options: ['Data collection', 'CPU', 'Memory', 'None'], correct: 0 },
            { question: 'A directory is basically a:', options: ['File list', 'CPU', 'RAM', 'None'], correct: 0 },
            { question: 'A file system manages:', options: ['Storage', 'CPU', 'Network', 'None'], correct: 0 },
            { question: 'Common file system types include:', options: ['FAT', 'NTFS', 'Both', 'None'], correct: 2 },
            { question: 'File access methods include:', options: ['Sequential', 'Direct', 'Both', 'None'], correct: 2 }
        ]
    },
    'DBMS (Database Management System)': {
        'ER Model': [
            { question: 'An entity in DBMS is a:', options: ['Object', 'Code', 'Table', 'None'], correct: 0 },
            { question: 'An attribute is a:', options: ['Property', 'Key', 'Value only', 'None'], correct: 0 },
            { question: 'A relationship represents a:', options: ['Link', 'Data type', 'Key', 'None'], correct: 0 },
            { question: 'An ER diagram is a:', options: ['Visual model', 'Code block', 'Query', 'None'], correct: 0 },
            { question: 'A key should generally be:', options: ['Unique', 'Duplicate', 'Null', 'None'], correct: 0 }
        ],
        'SQL Queries': [
            { question: 'SQL stands for:', options: ['Structured Query Language', 'Simple Query Language', 'System Query Logic', 'None'], correct: 0 },
            { question: 'SELECT is used to:', options: ['Insert', 'Delete', 'Retrieve', 'Update'], correct: 2 },
            { question: 'WHERE is used to:', options: ['Sort', 'Filter', 'Join', 'Group'], correct: 1 },
            { question: 'JOIN is used to:', options: ['Split', 'Combine', 'Delete', 'None'], correct: 1 },
            { question: 'GROUP BY is used to:', options: ['Group rows', 'Filter rows', 'Join tables', 'None'], correct: 0 }
        ],
        'Normalization': [
            { question: 'Normalization removes:', options: ['Redundancy', 'Data', 'Tables', 'None'], correct: 0 },
            { question: '1NF requires values to be:', options: ['Atomic', 'Complex', 'Null', 'None'], correct: 0 },
            { question: '2NF removes:', options: ['Partial dependency', 'Full dependency', 'None', 'All'], correct: 0 },
            { question: '3NF removes:', options: ['Transitive dependency', 'Partial dependency', 'None', 'All'], correct: 0 },
            { question: 'The main goal of normalization is:', options: ['Efficiency in design', 'Redundancy', 'Delay', 'None'], correct: 0 }
        ],
        'Transactions': [
            { question: 'ACID includes:', options: ['Atomicity', 'Consistency', 'Isolation', 'All'], correct: 3 },
            { question: 'COMMIT means:', options: ['Save changes', 'Delete changes', 'Error', 'None'], correct: 0 },
            { question: 'ROLLBACK means:', options: ['Undo changes', 'Save changes', 'Insert rows', 'None'], correct: 0 },
            { question: 'Isolation means transactions remain:', options: ['Separate', 'Merged', 'Deleted', 'None'], correct: 0 },
            { question: 'Atomicity means:', options: ['All or nothing', 'Half execution', 'None', 'Random'], correct: 0 }
        ],
        'Indexing': [
            { question: 'An index improves:', options: ['Speed', 'Memory usage', 'CPU temperature', 'None'], correct: 0 },
            { question: 'Index types include:', options: ['Primary', 'Secondary', 'Both', 'None'], correct: 2 },
            { question: 'B-tree is commonly used in:', options: ['Indexing', 'OS scheduling', 'CPU design', 'None'], correct: 0 },
            { question: 'An index stores:', options: ['Keys', 'Values', 'Both', 'None'], correct: 2 },
            { question: 'The benefit of indexing is:', options: ['Fast search', 'Slow access', 'None', 'Error'], correct: 0 }
        ]
    },
    'DT (Design Thinking)': {
        'Empathy Mapping': [
            { question: 'Empathy mapping focuses on the:', options: ['User', 'Code', 'Data', 'None'], correct: 0 },
            { question: 'The goal of empathy mapping is to:', options: ['Understand the user', 'Build code', 'Test software', 'None'], correct: 0 },
            { question: 'Empathy mapping includes what users:', options: ['Think', 'Feel', 'Say', 'All'], correct: 3 },
            { question: 'Empathy mapping is used in:', options: ['Design Thinking', 'Coding', 'Operating Systems', 'None'], correct: 0 },
            { question: 'The outcome of empathy mapping is:', options: ['Insights', 'Code', 'File', 'None'], correct: 0 }
        ],
        'Problem Definition': [
            { question: 'Problem definition defines the:', options: ['Problem', 'Code', 'Data', 'None'], correct: 0 },
            { question: 'A clear problem statement leads to a better:', options: ['Solution', 'Error', 'Delay', 'None'], correct: 0 },
            { question: 'Problem definition is based on:', options: ['Empathy', 'Code', 'Test cases', 'None'], correct: 0 },
            { question: 'The output of problem definition is a:', options: ['Statement', 'Code', 'Data', 'None'], correct: 0 },
            { question: 'Problem definition is typically the:', options: ['Second step', 'First step', 'Last step', 'None'], correct: 0 }
        ],
        'Ideation': [
            { question: 'Ideation means:', options: ['Idea generation', 'Coding', 'Testing', 'None'], correct: 0 },
            { question: 'Brainstorming is used for:', options: ['Generating ideas', 'Testing', 'Debugging', 'None'], correct: 0 },
            { question: 'The goal of ideation is to create:', options: ['Many ideas', 'One idea only', 'None', 'Execution'], correct: 0 },
            { question: 'Ideation involves creative thinking:', options: ['Yes', 'No', 'Maybe', 'None'], correct: 0 },
            { question: 'After ideation, teams usually move to:', options: ['Prototyping', 'Coding', 'Storage', 'None'], correct: 0 }
        ],
        'Prototyping': [
            { question: 'A prototype is a:', options: ['Model', 'Final product', 'Codebase', 'None'], correct: 0 },
            { question: 'Prototyping is used for:', options: ['Testing ideas', 'Coding only', 'Storage', 'None'], correct: 0 },
            { question: 'Prototype types include:', options: ['Low fidelity', 'High fidelity', 'Both', 'None'], correct: 2 },
            { question: 'The goal of a prototype is to:', options: ['Visualize ideas', 'Compile code', 'Store files', 'None'], correct: 0 },
            { question: 'Prototyping comes before:', options: ['Testing', 'Storage', 'Deployment only', 'None'], correct: 0 }
        ],
        'Testing': [
            { question: 'Testing in design thinking means:', options: ['Evaluate', 'Code', 'Store', 'None'], correct: 0 },
            { question: 'Testing is usually done on a:', options: ['Prototype', 'CPU', 'Code comment', 'None'], correct: 0 },
            { question: 'The main goal of testing is to get:', options: ['Feedback', 'Code', 'Error', 'None'], correct: 0 },
            { question: 'Testing helps improve the:', options: ['Design', 'CPU', 'Memory', 'None'], correct: 0 },
            { question: 'Testing is often treated as the final step in the basic cycle:', options: ['Yes', 'No', 'Maybe', 'None'], correct: 0 }
        ]
    },
    'IWT (Introduction to Web Technology)': {
        'HTML & CSS': [
            { question: 'HTML is a:', options: ['Markup language', 'Programming language', 'Database', 'Operating system'], correct: 0 },
            { question: 'CSS is used for:', options: ['Styling', 'Logic', 'Database queries', 'None'], correct: 0 },
            { question: 'Which of these is an HTML tag?', options: ['<p>', 'var', 'int', 'None'], correct: 0 },
            { question: 'CSS stands for:', options: ['Cascading Style Sheets', 'Code Style Sheets', 'Control Style System', 'None'], correct: 0 },
            { question: 'HTML and CSS are mainly used in:', options: ['Web development', 'OS design', 'DBMS internals', 'None'], correct: 0 }
        ],
        'JavaScript': [
            { question: 'JavaScript is a:', options: ['Language', 'Operating system', 'Database', 'Compiler'], correct: 0 },
            { question: 'JavaScript runs on:', options: ['Browser', 'Server', 'Both', 'None'], correct: 2 },
            { question: 'A JavaScript variable can be declared using:', options: ['var', 'int', 'float', 'char'], correct: 0 },
            { question: 'A function is a:', options: ['Code block', 'Loop', 'Variable', 'None'], correct: 0 },
            { question: '=== means:', options: ['Strict equal', 'Equal only', 'Assign', 'None'], correct: 0 }
        ],
        'Frontend Frameworks': [
            { question: 'An example of a frontend framework or library is:', options: ['React', 'MySQL', 'Java', 'None'], correct: 0 },
            { question: 'Frontend frameworks are mainly used for:', options: ['UI', 'Database', 'Operating system', 'None'], correct: 0 },
            { question: 'Component-based architecture is common in frontend frameworks:', options: ['Yes', 'No', 'Maybe', 'None'], correct: 0 },
            { question: 'Angular is a:', options: ['Framework', 'Database', 'Operating system', 'None'], correct: 0 },
            { question: 'Frontend frameworks usually improve:', options: ['Development speed', 'Delay', 'Error count intentionally', 'None'], correct: 0 }
        ],
        'Backend Basics': [
            { question: 'The backend mainly handles the:', options: ['Server', 'UI only', 'Page styling', 'None'], correct: 0 },
            { question: 'A backend technology example is:', options: ['Node.js', 'HTML', 'CSS', 'None'], correct: 0 },
            { question: 'A database usually connects through the:', options: ['Backend', 'UI only', 'CSS', 'None'], correct: 0 },
            { question: 'An API is used for:', options: ['Communication', 'Design only', 'Styling', 'None'], correct: 0 },
            { question: 'A server commonly stores:', options: ['Data', 'UI paint only', 'CSS gradients only', 'None'], correct: 0 }
        ],
        'APIs': [
            { question: 'API stands for:', options: ['Application Programming Interface', 'App Process Integration', 'Advanced Program Input', 'System'], correct: 0 },
            { question: 'APIs are mainly used for:', options: ['Communication', 'Styling', 'UI layout', 'None'], correct: 0 },
            { question: 'An example of an API style is:', options: ['REST', 'HTML', 'CSS', 'None'], correct: 0 },
            { question: 'APIs usually return:', options: ['Data', 'Style sheets', 'UI components only', 'None'], correct: 0 },
            { question: 'APIs are widely used in:', options: ['Web apps', 'Operating systems only', 'Databases only', 'None'], correct: 0 }
        ]
    }
};

const MOTIVATIONAL_QUOTES = [
    'Stay consistent. Small steps every day lead to big results.',
    'Your future self will thank you for the work you do today.',
    'Progress beats perfection when you keep showing up.',
    'One focused study session can change your whole week.',
    'Discipline today creates confidence on exam day.',
    'Keep going. Every topic you finish builds momentum.',
    'Small improvements each day become strong results over time.',
    'You do not need to do everything today, just the next right thing.',
    'Focused effort now makes revision easier later.',
    'Consistency turns difficult subjects into familiar ones.'
];

class StudyApp {
    constructor() {
        this.currentPage = 'dashboard';
        this.state = this.loadState();
        this.quizState = null;
        this.adjustmentMessage = '';
        this.dailyQuote = this.getRandomQuote();
        this.studyPlanWeekIndex = 0;
        this.init();
    }

    init() {
        this.refreshStoredPlanDates();
        this.updateAchievements();
        this.saveState();
        this.setupEventListeners();
        this.setupTheme();
        this.updateThemeIcon();
        this.updateDateTime();
        this.renderPlannerForm();
        this.handleAutomaticAdjustment();
        this.renderAll();
        setInterval(() => this.updateDateTime(), 60000);
    }

    getUserStorageKey(baseKey) {
        const userEmail = window.authManager?.currentUser?.email || 'guest';
        return `${baseKey}_${userEmail}`;
    }

    loadState() {
        const stored = localStorage.getItem(this.getUserStorageKey('adaptiveStudyState'));
        const defaults = {
            profile: null,
            plan: null,
            activityLog: [],
            adjustmentLog: [],
            quizResults: {},
            studyLog: [],
            achievements: {
                firstQuiz: false,
                studyStreak: false,
                perfectScore: false
            }
        };

        if (!stored) return defaults;

        const parsed = JSON.parse(stored);
        return {
            ...defaults,
            ...parsed,
            studyLog: Array.isArray(parsed.studyLog) ? parsed.studyLog : [],
            achievements: {
                ...defaults.achievements,
                ...(parsed.achievements || {})
            }
        };
    }

    refreshStoredPlanDates() {
        if (!this.state.profile || !this.state.plan) return;
        const refreshedPlan = planner.generatePlan(this.state.profile);
        if (!refreshedPlan.error) {
            this.state.plan = refreshedPlan;
            this.saveState();
        }
    }

    saveState() {
        localStorage.setItem(this.getUserStorageKey('adaptiveStudyState'), JSON.stringify(this.state));
    }

    setupEventListeners() {
        document.querySelectorAll('.nav-item').forEach((item) => {
            item.addEventListener('click', (event) => {
                const button = event.target.closest('.nav-item');
                this.navigateTo(button.dataset.page);
            });
        });

        document.getElementById('menuToggle')?.addEventListener('click', () => {
            document.querySelector('.sidebar')?.classList.toggle('active');
        });

        document.getElementById('themeToggle')?.addEventListener('click', () => this.toggleTheme());

        document.getElementById('logoutBtn')?.addEventListener('click', () => {
            if (window.authManager && confirm('Logout from your study planner?')) {
                window.authManager.logout();
            }
        });

        document.getElementById('plannerForm')?.addEventListener('submit', (event) => {
            event.preventDefault();
            this.generatePlanFromForm();
        });

        document.getElementById('examDate')?.addEventListener('input', () => this.handlePlannerInputChange());
        document.getElementById('availableHours')?.addEventListener('input', () => this.handlePlannerInputChange());

        document.getElementById('resetPlannerBtn')?.addEventListener('click', () => this.resetPlannerForm());
        document.getElementById('recalculatePlanBtn')?.addEventListener('click', () => this.recalculatePlan(true));
        document.getElementById('downloadPdfBtn')?.addEventListener('click', () => this.downloadPlanPdf());
        document.getElementById('studyPlanPrevBtn')?.addEventListener('click', () => this.changeStudyPlanWeek(-1));
        document.getElementById('studyPlanNextBtn')?.addEventListener('click', () => this.changeStudyPlanWeek(1));

        document.addEventListener('click', (event) => {
            if (event.target.classList.contains('topic-toggle')) {
                this.toggleTopicCompletion(
                    event.target.dataset.subjectId,
                    event.target.dataset.topicId,
                    event.target.checked
                );
            }

            if (event.target.classList.contains('start-quiz-btn')) {
                this.openQuiz(event.target.dataset.subjectId, event.target.dataset.topicId);
            }

            if (event.target.classList.contains('modal-close')) {
                event.target.closest('.modal')?.classList.remove('active');
            }

            if (event.target.id === 'quizNextBtn') {
                this.submitQuizAnswer();
            }

            if (event.target.id === 'quizCloseBtn') {
                document.getElementById('quizModal')?.classList.remove('active');
            }

            if (event.target.id === 'studyPlanPrevBtn') {
                this.changeStudyPlanWeek(-1);
            }

            if (event.target.id === 'studyPlanNextBtn') {
                this.changeStudyPlanWeek(1);
            }
        });

        document.addEventListener('change', (event) => {
            if (event.target.classList.contains('subject-difficulty-select')) {
                this.updateSubjectDifficulty(event.target.dataset.subjectId, event.target.value);
            }
        });

        document.querySelectorAll('.modal').forEach((modal) => {
            modal.addEventListener('click', (event) => {
                if (event.target === modal) {
                    modal.classList.remove('active');
                }
            });
        });
    }

    setupTheme() {
        const savedTheme = localStorage.getItem(this.getUserStorageKey('theme')) || 'light';
        if (savedTheme === 'dark') {
            document.body.classList.add('dark-mode');
        }
    }

    toggleTheme() {
        const isDark = document.body.classList.toggle('dark-mode');
        localStorage.setItem(this.getUserStorageKey('theme'), isDark ? 'dark' : 'light');
        this.updateThemeIcon();
    }

    updateThemeIcon() {
        const icon = document.querySelector('.theme-icon');
        if (icon) icon.textContent = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
    }

    updateDateTime() {
        const dateTime = document.getElementById('dateTime');
        if (!dateTime) return;
        dateTime.textContent = new Date().toLocaleString('en-US', {
            weekday: 'long',
            month: 'long',
            day: 'numeric',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    navigateTo(pageId) {
        document.querySelector('.sidebar')?.classList.remove('active');
        document.querySelectorAll('.page').forEach((page) => page.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach((item) => item.classList.remove('active'));
        document.getElementById(pageId)?.classList.add('active');
        document.querySelector(`.nav-item[data-page="${pageId}"]`)?.classList.add('active');
        this.currentPage = pageId;
        this.renderPage(pageId);
    }

    renderPage(pageId) {
        if (pageId === 'dashboard') this.renderDashboard();
        if (pageId === 'planner') this.renderPlannerForm();
        if (pageId === 'schedule') this.renderSchedulePage();
        if (pageId === 'progress') this.renderProgressPage();
    }

    renderAll() {
        this.updateWelcomeMessage();
        this.renderDashboard();
        this.renderSchedulePage();
        this.renderProgressPage();
        if (!this.state.profile) this.navigateTo('planner');
    }

    updateWelcomeMessage() {
        const welcomeEl = document.getElementById('welcomeMessage');
        if (welcomeEl) {
            const userName = window.authManager?.currentUser?.name || 'Student';
            welcomeEl.textContent = `Welcome, ${userName}`;
        }
    }

    renderDailyMotivation() {
        const quoteEl = document.getElementById('dailyQuote');
        if (quoteEl) {
            quoteEl.textContent = this.dailyQuote;
        }
    }

    renderPlannerForm() {
        const profile = this.state.profile;
        document.getElementById('university').value = profile?.university || '';
        document.getElementById('year').value = profile?.year || '';
        document.getElementById('selectedBranchName').value = profile?.branchLabel || '';
        document.getElementById('selectedSemesterName').value = profile?.semester ? `Semester ${profile.semester}` : '';
        document.getElementById('examDate').value = profile?.examDate || '';
        document.getElementById('availableHours').value = profile?.availableHours || 3;
        this.renderBranchSelector();
        this.renderSemesterSelector();
        this.renderSemesterSubjectsPreview();
    }

    renderBranchSelector() {
        const container = document.getElementById('branchSelector');
        if (!container) return;
        const selectedBranch = this.state.profile?.branch || '';
        container.innerHTML = Object.entries(ENGINEERING_DATA).map(([branchKey, branchData]) => `
            <button type="button" class="branch-card ${selectedBranch === branchKey ? 'active' : ''}" data-branch-key="${branchKey}">
                <strong>${this.escapeHtml(branchData.label)}</strong>
                <span>${Object.keys(branchData.semesters).length} semesters</span>
            </button>
        `).join('');

        container.querySelectorAll('.branch-card').forEach((button) => {
            button.addEventListener('click', () => this.selectBranch(button.dataset.branchKey));
        });
    }

    renderSemesterSelector() {
        const container = document.getElementById('semesterSelector');
        if (!container) return;
        const selectedSemester = Number(this.state.profile?.semester || 0);
        container.innerHTML = Array.from({ length: 8 }, (_, index) => index + 1).map((semester) => `
            <button type="button" class="semester-pill ${selectedSemester === semester ? 'active' : ''}" data-semester="${semester}">
                Semester ${semester}
            </button>
        `).join('');

        container.querySelectorAll('.semester-pill').forEach((button) => {
            button.addEventListener('click', () => this.selectSemester(Number(button.dataset.semester)));
        });
    }

    renderSemesterSubjectsPreview() {
        const container = document.getElementById('semesterSubjects');
        if (!container) return;

        const profile = this.state.profile;
        if (!profile?.branch || !profile?.semester) {
            container.innerHTML = '<p class="empty-state">Select a branch and semester to load subjects and topics.</p>';
            return;
        }

        const subjects = this.getSubjectsForSelection(profile.branch, profile.semester, profile.subjects);
        const allocation = this.getTimeAllocationPreview({
            ...profile,
            subjects
        });
        container.innerHTML = subjects.map((subject) => `
            <div class="subject-builder-card glass">
                <div class="subject-builder-top">
                    <div>
                        <h4>${this.escapeHtml(subject.name)}</h4>
                        <p class="allocation-copy">${this.escapeHtml(this.getSubjectAllocationText(subject, allocation))}</p>
                    </div>
                    <div>
                        <span class="subject-count-badge">${subject.topics.length} topics</span>
                        <div class="allocation-copy small">Difficulty</div>
                        <select class="subject-difficulty-select" data-subject-id="${subject.id}">
                            <option value="easy" ${subject.difficulty === 'easy' ? 'selected' : ''}>Easy</option>
                            <option value="moderate" ${subject.difficulty === 'moderate' ? 'selected' : ''}>Moderate</option>
                            <option value="difficult" ${subject.difficulty === 'difficult' ? 'selected' : ''}>Difficult</option>
                        </select>
                    </div>
                </div>
                <div class="preview-topic-list">
                    ${subject.topics.map((topic) => `
                        <div class="preview-topic-item ${topic.completed ? 'completed' : ''}">
                            <div>
                                <span>${this.escapeHtml(topic.name)}</span>
                                <div class="allocation-copy small">${this.escapeHtml(this.getTopicAllocationText(subject, topic, allocation))}</div>
                            </div>
                            <span>${topic.completed ? 'Done' : 'Pending'}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `).join('');
    }

    selectBranch(branchKey) {
        const branchData = ENGINEERING_DATA[branchKey];
        if (!branchData) return;

        const previousSubjects = this.state.profile?.subjects || [];
        this.state.profile = {
            ...(this.state.profile || {}),
            branch: branchKey,
            branchLabel: branchData.label,
            semester: this.state.profile?.semester || 1,
            subjects: this.getSubjectsForSelection(branchKey, this.state.profile?.semester || 1, previousSubjects)
        };

        document.getElementById('selectedBranchName').value = branchData.label;
        document.getElementById('selectedSemesterName').value = `Semester ${this.state.profile.semester}`;
        this.saveState();
        this.renderPlannerForm();
    }

    selectSemester(semester) {
        if (!this.state.profile?.branch) {
            alert('Select an engineering branch first.');
            return;
        }

        this.state.profile = {
            ...this.state.profile,
            semester,
            subjects: this.getSubjectsForSelection(this.state.profile.branch, semester, this.state.profile.subjects || [])
        };

        document.getElementById('selectedSemesterName').value = `Semester ${semester}`;
        this.saveState();
        this.renderPlannerForm();
    }

    getSubjectsForSelection(branchKey, semester, existingSubjects = []) {
        const semesterData = ENGINEERING_DATA[branchKey]?.semesters?.[semester];
        if (!semesterData) return [];

        return semesterData.subjects.map((subject, subjectIndex) => {
            const existingSubject = existingSubjects.find((item) => item.name === subject.name);
            return {
                id: `${branchKey}-sem-${semester}-subject-${subjectIndex}-${this.slugify(subject.name)}`,
                name: subject.name,
                difficulty: existingSubject?.difficulty || 'moderate',
                topics: subject.topics.map((topic, topicIndex) => {
                    const existingTopic = existingSubject?.topics?.find((item) => item.name === topic);
                    return {
                        id: `${branchKey}-sem-${semester}-subject-${subjectIndex}-topic-${topicIndex}-${this.slugify(topic)}`,
                        name: topic,
                        completed: existingTopic?.completed || false
                    };
                })
            };
        });
    }

    resetPlannerForm() {
        this.state.profile = null;
        this.state.plan = null;
        this.studyPlanWeekIndex = 0;
        this.adjustmentMessage = '';
        this.saveState();
        this.renderPlannerForm();
        this.renderAll();
    }

    updateSubjectDifficulty(subjectId, difficulty) {
        const subject = this.state.profile?.subjects?.find((entry) => entry.id === subjectId);
        if (!subject) return;

        subject.difficulty = difficulty;

        if (this.state.plan && this.state.profile) {
            this.state.plan = planner.generatePlan(this.state.profile);
        }

        this.saveState();
        this.renderSemesterSubjectsPreview();
        this.renderSchedulePage();
        this.renderDashboard();
    }

    generatePlanFromForm() {
        if (!this.state.profile?.branch || !this.state.profile?.semester) {
            alert('Select both an engineering branch and a semester.');
            return;
        }

        const profile = {
            university: document.getElementById('university').value.trim(),
            year: document.getElementById('year').value.trim(),
            semester: this.state.profile.semester,
            branch: this.state.profile.branch,
            branchLabel: this.state.profile.branchLabel,
            examDate: document.getElementById('examDate').value,
            availableHours: Number(document.getElementById('availableHours').value),
            subjects: this.getSubjectsForSelection(this.state.profile.branch, this.state.profile.semester, this.state.profile.subjects || [])
        };

        const plan = planner.generatePlan(profile);
        if (plan.error) {
            alert(plan.error);
            return;
        }

        this.state.profile = profile;
        this.state.plan = plan;
        this.studyPlanWeekIndex = 0;
        this.adjustmentMessage = 'Your adaptive study plan is ready.';
        this.pushActivity('Study plan generated.');
        this.pushAdjustment('Initial plan created from your current syllabus and available time.');
        this.saveState();
        this.renderAll();
        this.navigateTo('schedule');
    }

    handleAutomaticAdjustment() {
        if (!this.state.profile || !this.state.plan) return;
        const today = this.todayISO();
        const hasMissedSessions = this.state.plan.sessions.some((session) => session.status === 'pending' && session.date < today);
        if (hasMissedSessions) {
            this.recalculatePlan(false, 'Missed study day detected. Remaining syllabus was automatically redistributed.');
        }
    }

    recalculatePlan(manual = false, message = 'Plan updated based on remaining syllabus.') {
        if (!this.state.profile) {
            alert('Fill in your planner details first.');
            return;
        }

        const updatedPlan = planner.generatePlan(this.state.profile);
        if (updatedPlan.error) {
            alert(updatedPlan.error);
            return;
        }

        this.state.plan = updatedPlan;
        this.studyPlanWeekIndex = 0;
        this.adjustmentMessage = message;
        this.pushAdjustment(manual ? 'Manual recalculation completed.' : 'Automatic recalculation completed after missed study time.');
        this.pushActivity(manual ? 'Study plan recalculated manually.' : 'Study plan adjusted automatically.');
        this.saveState();
        this.renderAll();
    }

    toggleTopicCompletion(subjectId, topicId, completed) {
        const topic = this.findTopic(subjectId, topicId);
        if (!topic) return;
        const wasCompleted = topic.completed;
        topic.completed = completed;
        if (completed && !wasCompleted) {
            this.recordStudyDay();
        }
        this.pushActivity(`${completed ? 'Completed' : 'Reopened'} topic: ${topic.name}`);
        this.state.plan = planner.generatePlan(this.state.profile);
        this.studyPlanWeekIndex = 0;
        this.updateAchievements();
        this.saveState();
        this.renderAll();
    }

    findTopic(subjectId, topicId) {
        const subject = this.state.profile?.subjects.find((entry) => entry.id === subjectId);
        return subject?.topics.find((topic) => topic.id === topicId) || null;
    }

    renderDashboard() {
        this.updateDashboardStats();
        this.renderDailyMotivation();
        this.renderStudentSnapshot();
        this.renderPlannerStatus();
        this.renderInsights();
        this.renderMotivation();
    }

    updateDashboardStats() {
        const metrics = this.getMetrics();
        document.getElementById('daysLeftStat').textContent = metrics.daysLeft;
        document.getElementById('remainingTopicsStat').textContent = metrics.remainingTopics;
        document.getElementById('remainingHoursStat').textContent = metrics.remainingHours;
        document.getElementById('progressPercent').textContent = `${metrics.progressPercent}%`;

        const circle = document.getElementById('progressCircle');
        if (circle) {
            const circumference = 2 * Math.PI * 45;
            circle.style.strokeDasharray = `${circumference}`;
            circle.style.strokeDashoffset = `${circumference * (1 - metrics.progressPercent / 100)}`;
        }
    }

    renderStudentSnapshot() {
        const container = document.getElementById('studentSnapshot');
        if (!container) return;
        if (!this.state.profile) {
            container.innerHTML = '<p class="empty-state">Set up your planner to see your academic profile.</p>';
            return;
        }

        const profile = this.state.profile;
        container.innerHTML = `
            <div class="summary-row"><strong>University:</strong><span>${this.escapeHtml(profile.university)}</span></div>
            <div class="summary-row"><strong>Branch:</strong><span>${this.escapeHtml(profile.branchLabel || '')}</span></div>
            <div class="summary-row"><strong>Year:</strong><span>${this.escapeHtml(profile.year)}</span></div>
            <div class="summary-row"><strong>Semester:</strong><span>Semester ${this.escapeHtml(profile.semester)}</span></div>
            <div class="summary-row"><strong>Subjects:</strong><span>${profile.subjects.length}</span></div>
            <div class="summary-row"><strong>Study Hours/Day:</strong><span>${profile.availableHours}</span></div>
        `;
    }

    renderPlannerStatus() {
        const container = document.getElementById('plannerStatus');
        if (!container) return;
        if (!this.state.plan || !this.state.profile) {
            container.innerHTML = '<p class="empty-state">No study plan yet. Fill your details and generate one.</p>';
            return;
        }

        const metrics = this.getMetrics();
        const subjectTimeBreakdown = this.getSubjectTimeBreakdown();
        container.innerHTML = `
            <div class="summary-row"><strong>Branch:</strong><span>${this.escapeHtml(this.state.profile.branchLabel || '')}</span></div>
            <div class="summary-row"><strong>Semester:</strong><span>Semester ${this.escapeHtml(this.state.profile.semester)}</span></div>
            <div class="summary-row"><strong>Exam Date:</strong><span>${this.formatDate(this.state.profile.examDate)}</span></div>
            <div class="summary-row"><strong>Total Topics:</strong><span>${metrics.totalTopics}</span></div>
            <div class="summary-row"><strong>Completed:</strong><span>${metrics.completedTopics}</span></div>
            ${subjectTimeBreakdown}
            <div class="summary-row"><strong>Recommendation:</strong><span>${this.escapeHtml(this.state.plan.recommendation)}</span></div>
        `;
    }

    renderInsights() {
        const container = document.getElementById('aiInsights');
        if (!container) return;
        if (!this.state.profile) {
            container.innerHTML = '<p class="empty-state">Your recommendations will appear here after you create your plan.</p>';
            return;
        }

        const metrics = this.getMetrics();
        const weakestSubject = this.getWeakestSubject();
        const insights = [];

        if (metrics.remainingTopics > 0) {
            insights.push({ title: 'Remaining Focus', message: `${metrics.remainingTopics} topics are still pending. Prioritize the next scheduled sessions first.` });
        }
        if (weakestSubject) {
            insights.push({ title: 'Weakest Subject', message: `${weakestSubject.name} has the lowest completion rate. Give it the first study block tomorrow.` });
        }
        if (metrics.daysLeft <= 7) {
            insights.push({ title: 'Final Week Mode', message: 'Use the last week for revision, quick quizzes, and short high-focus study sessions.' });
        } else {
            insights.push({ title: 'Consistency', message: 'Complete topics in small daily blocks so missed days are easier for the planner to absorb.' });
        }

        container.innerHTML = insights.map((insight) => `<div class="insight-item"><strong>${insight.title}:</strong> ${insight.message}</div>`).join('');
    }

    renderMotivation() {
        const el = document.getElementById('motivationText');
        if (!el) return;
        const metrics = this.getMetrics();
        if (metrics.daysLeft <= 7 && metrics.daysLeft > 0) {
            const messages = [
                'Final week energy: stay calm, revise smart, and trust the work you have already put in.',
                'You are in the last stretch. Focus on high-yield revision and finish one topic at a time.',
                'Exam week is near. Keep your routine simple, steady, and confidence-building.'
            ];
            el.textContent = messages[metrics.daysLeft % messages.length];
            return;
        }
        el.textContent = 'Plan your day, finish your topics, and let the system adapt whenever your schedule changes.';
    }

    renderSchedulePage() {
        this.renderAdjustmentNotice();
        this.renderPlanSummary();
        this.renderTodaySchedule();
        this.renderStudyPlan();
        this.renderSyllabusTracker();
    }

    renderAdjustmentNotice() {
        const banner = document.getElementById('adjustmentNotice');
        if (!banner) return;
        if (!this.adjustmentMessage) {
            banner.classList.add('hidden');
            banner.textContent = '';
            return;
        }
        banner.classList.remove('hidden');
        banner.textContent = this.adjustmentMessage;
    }

    renderPlanSummary() {
        const container = document.getElementById('planSummary');
        if (!container) return;
        if (!this.state.plan || !this.state.profile) {
            container.innerHTML = '<p class="empty-state">Generate your plan to view the summary.</p>';
            return;
        }
        const subjectTimeBreakdown = this.getSubjectTimeBreakdown();
        container.innerHTML = `
            <div class="summary-row"><strong>Days Until Exam:</strong><span>${this.state.plan.daysUntilExam}</span></div>
            <div class="summary-row"><strong>Total Available Time:</strong><span>${this.state.plan.totalAvailableHours} hours</span></div>
            <div class="summary-row"><strong>Required Study Time:</strong><span>${this.state.plan.totalRequiredHours} hours</span></div>
            <div class="summary-row"><strong>Remaining Topics:</strong><span>${this.state.plan.remainingTopics}</span></div>
            ${subjectTimeBreakdown}
            <div class="summary-note">${this.escapeHtml(this.state.plan.recommendation)}</div>
        `;
    }

    renderTodaySchedule() {
        const container = document.getElementById('todaySchedule');
        if (!container) return;
        if (!this.state.plan?.sessions?.length) {
            container.innerHTML = '<p class="empty-state">Today\'s study sessions will appear here.</p>';
            return;
        }

        const todaysSessions = this.state.plan.sessions.filter((session) => session.date === this.todayISO());
        if (!todaysSessions.length) {
            container.innerHTML = '<p class="empty-state">No sessions scheduled for today. Use the time for revision or recalculate your plan.</p>';
            return;
        }

        container.innerHTML = todaysSessions.map((session) => `
            <div class="task-item">
                <div class="task-text"><strong>${this.escapeHtml(session.subjectName)}</strong><br><span>${this.escapeHtml(session.topicName)} • ${session.durationHours} hr</span></div>
                <span class="task-category">${session.status}</span>
            </div>
        `).join('');
    }

    renderStudyPlan() {
        const container = document.getElementById('studyPlanList');
        if (!container) return;
        if (!this.state.plan?.sessions?.length) {
            container.innerHTML = '<p class="empty-state">No study plan generated yet.</p>';
            return;
        }

        const weeks = this.buildStudyPlanWeeks(this.state.plan.sessions);
        this.studyPlanWeekIndex = Math.min(this.studyPlanWeekIndex, Math.max(weeks.length - 1, 0));
        const activeWeek = weeks[this.studyPlanWeekIndex] || [];
        const firstDay = activeWeek[0];
        const lastDay = activeWeek[activeWeek.length - 1];

        container.innerHTML = `
            <div class="study-plan-nav">
                <button type="button" class="btn btn-secondary" id="studyPlanPrevBtn" ${this.studyPlanWeekIndex === 0 ? 'disabled' : ''}>&lsaquo;</button>
                <div class="study-plan-range">
                    Week ${this.studyPlanWeekIndex + 1} of ${weeks.length}
                    <span>${this.escapeHtml(this.formatDate(firstDay.date))} - ${this.escapeHtml(this.formatDate(lastDay.date))}</span>
                </div>
                <button type="button" class="btn btn-secondary" id="studyPlanNextBtn" ${this.studyPlanWeekIndex >= weeks.length - 1 ? 'disabled' : ''}>&rsaquo;</button>
            </div>
            <div class="study-plan-week-row">
                ${activeWeek.map((day, index) => `
                    <div class="plan-day glass ${day.sessions.length ? '' : 'plan-day-empty'}">
                        <div class="plan-day-header">
                            ${this.escapeHtml(day.weekday)}
                            <span>${day.sessions.length ? `Day ${this.getDayNumberFromSessions(day.sessions)} • ${this.escapeHtml(day.label)}` : this.escapeHtml(day.label)}</span>
                        </div>
                        <div class="plan-activities">
                            ${day.sessions.length ? day.sessions.map((session) => `
                                <div class="activity">
                                    <div class="activity-subject">${this.escapeHtml(session.subjectName)}</div>
                                    <div class="activity-task">${this.escapeHtml(session.topicName)}</div>
                                    <div class="activity-time">${session.durationHours} hour(s) • ${session.status}</div>
                                </div>
                            `).join('') : '<p class="empty-state">No study plan for this day.</p>'}
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    changeStudyPlanWeek(direction) {
        if (!this.state.plan?.sessions?.length) return;
        const weeks = this.buildStudyPlanWeeks(this.state.plan.sessions);
        const nextIndex = this.studyPlanWeekIndex + direction;
        if (nextIndex < 0 || nextIndex >= weeks.length) return;
        this.studyPlanWeekIndex = nextIndex;
        this.renderStudyPlan();
    }

    downloadPlanPdf() {
        if (!this.state.plan?.sessions?.length) {
            alert('Generate a study plan before downloading the PDF.');
            return;
        }

        if (!window.jspdf?.jsPDF) {
            alert('jsPDF is not loaded.');
            return;
        }

        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF();
        const profile = this.state.profile || {};
        const groupedSessions = this.groupSessionsByDate(this.state.plan.sessions);
        let y = 20;

        pdf.setFontSize(18);
        pdf.text('Adaptive Study Plan', 14, y);
        y += 10;

        pdf.setFontSize(11);
        pdf.text(`University: ${profile.university || 'N/A'}`, 14, y);
        y += 7;
        pdf.text(`Branch: ${profile.branchLabel || 'N/A'}`, 14, y);
        y += 7;
        pdf.text(`Semester: ${profile.semester || 'N/A'}`, 14, y);
        y += 7;
        pdf.text(`Exam Date: ${profile.examDate || 'N/A'}`, 14, y);
        y += 10;

        Object.entries(groupedSessions).forEach(([date, sessions], index) => {
            if (y > 260) {
                pdf.addPage();
                y = 20;
            }

            pdf.setFontSize(13);
            pdf.text(`Day ${index + 1} - ${sessions[0]?.dateLabel || date}`, 14, y);
            y += 8;

            pdf.setFontSize(10);
            sessions.forEach((session) => {
                const line = `${session.subjectName}: ${session.topicName} (${session.durationHours} hr)`;
                const wrappedLine = pdf.splitTextToSize(line, 180);
                pdf.text(wrappedLine, 18, y);
                y += wrappedLine.length * 6;
            });

            y += 4;
        });

        pdf.save('study-plan.pdf');
    }

    renderSyllabusTracker() {
        const container = document.getElementById('syllabusGrid');
        if (!container) return;
        if (!this.state.profile?.subjects?.length) {
            container.innerHTML = '<p class="empty-state">Add subjects and topics to start tracking your syllabus.</p>';
            return;
        }

        const allocation = this.getTimeAllocationPreview(this.state.profile);
        container.innerHTML = this.state.profile.subjects.map((subject) => {
            const completedTopics = subject.topics.filter((topic) => topic.completed).length;
            const percent = subject.topics.length ? Math.round((completedTopics / subject.topics.length) * 100) : 0;
            return `
                <div class="subject-card glass tracker-card">
                    <div class="subject-name">${this.escapeHtml(subject.name)}</div>
                    <div class="subject-topics">${completedTopics}/${subject.topics.length} topics completed</div>
                    <div class="allocation-copy">${this.escapeHtml(this.getSubjectAllocationText(subject, allocation))}</div>
                    <div class="progress-bar-container"><div class="progress-bar" style="width: ${percent}%"></div></div>
                    <div class="topics-list topic-tracker-list">
                        ${subject.topics.map((topic) => `
                            <div class="topic-item topic-tracker-item">
                                <div class="topic-header">
                                    <div>
                                        <span class="topic-name">${this.escapeHtml(topic.name)}</span>
                                        <div class="allocation-copy small">${this.escapeHtml(this.getTopicAllocationText(subject, topic, allocation))}</div>
                                    </div>
                                    <label class="topic-check-label">
                                        <input type="checkbox" class="topic-toggle" data-subject-id="${subject.id}" data-topic-id="${topic.id}" ${topic.completed ? 'checked' : ''}>
                                        <span>Done</span>
                                    </label>
                                </div>
                                <div class="topic-actions">
                                    <button type="button" class="btn btn-secondary start-quiz-btn" data-subject-id="${subject.id}" data-topic-id="${topic.id}">${this.getQuizButtonLabel(subject.id, topic.id)}</button>
                                    <span class="quiz-badge">${this.getQuizBadge(subject.id, topic.id)}</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }).join('');
    }

    renderProgressPage() {
        const metrics = this.getMetrics();
        document.getElementById('progressSubjects').textContent = this.state.profile?.subjects?.length || 0;
        document.getElementById('progressTopicsCompleted').textContent = metrics.completedTopics;
        document.getElementById('progressTopicsRemaining').textContent = metrics.remainingTopics;
        document.getElementById('progressQuizAverage').textContent = `${metrics.averageQuizScore}%`;
        this.renderAchievements();
        this.renderSubjectProgressList();
        this.renderActivityLog();
        this.renderAdjustmentLog();
    }

    renderAchievements() {
        const container = document.getElementById('achievementsList');
        if (!container) return;

        const achievements = [
            { icon: '🎯', title: 'First Quiz', unlocked: Boolean(this.state.achievements?.firstQuiz) },
            { icon: '🔥', title: 'Study Streak', unlocked: Boolean(this.state.achievements?.studyStreak) },
            { icon: '🏆', title: 'Perfect Score', unlocked: Boolean(this.state.achievements?.perfectScore) }
        ];

        container.innerHTML = achievements.map((achievement) => `
            <div class="achievement-item ${achievement.unlocked ? 'unlocked' : 'locked'}">
                <div class="achievement-icon">${achievement.icon}</div>
                <div class="achievement-info">
                    <div class="achievement-title">${achievement.title}</div>
                    <div class="achievement-status">${achievement.unlocked ? 'Unlocked ✅' : 'Locked 🔒'}</div>
                </div>
            </div>
        `).join('');
    }

    renderSubjectProgressList() {
        const container = document.getElementById('subjectProgressList');
        if (!container) return;
        if (!this.state.profile?.subjects?.length) {
            container.innerHTML = '<p class="empty-state">Subject progress will appear here.</p>';
            return;
        }

        container.innerHTML = this.state.profile.subjects.map((subject) => {
            const completed = subject.topics.filter((topic) => topic.completed).length;
            const percentage = subject.topics.length ? Math.round((completed / subject.topics.length) * 100) : 0;
            const quizAverage = this.getSubjectQuizAverage(subject.id);
            return `
                <div class="subject-progress-item">
                    <div class="subject-header">
                        <span class="subject-name">${this.escapeHtml(subject.name)}</span>
                        <span class="subject-stats">${completed}/${subject.topics.length} topics • ${quizAverage}% avg quiz</span>
                    </div>
                    <div class="progress-bar-container"><div class="progress-bar" style="width: ${percentage}%"></div></div>
                </div>
            `;
        }).join('');
    }

    renderActivityLog() {
        const container = document.getElementById('recentActivity');
        if (!container) return;
        const items = this.state.activityLog.slice(0, 6);
        if (!items.length) {
            container.innerHTML = '<p class="empty-state">Your activity log will appear here.</p>';
            return;
        }
        container.innerHTML = items.map((item) => `
            <div class="activity-item">
                <div class="activity-icon">📝</div>
                <div class="activity-info">
                    <div class="activity-title">${this.escapeHtml(item.message)}</div>
                    <div class="activity-detail">${this.formatDateTime(item.timestamp)}</div>
                </div>
            </div>
        `).join('');
    }

    renderAdjustmentLog() {
        const container = document.getElementById('adjustmentHistory');
        if (!container) return;
        const items = this.state.adjustmentLog.slice(0, 6);
        if (!items.length) {
            container.innerHTML = '<p class="empty-state">Plan recalculations and missed-day updates will appear here.</p>';
            return;
        }
        container.innerHTML = items.map((item) => `
            <div class="activity-item">
                <div class="activity-icon">🔄</div>
                <div class="activity-info">
                    <div class="activity-title">${this.escapeHtml(item.message)}</div>
                    <div class="activity-detail">${this.formatDateTime(item.timestamp)}</div>
                </div>
            </div>
        `).join('');
    }

    openQuiz(subjectId, topicId) {
        const subject = this.state.profile?.subjects.find((entry) => entry.id === subjectId);
        const topic = subject?.topics.find((entry) => entry.id === topicId);
        if (!subject || !topic) return;

        this.quizState = {
            subjectId,
            topicId,
            subjectName: subject.name,
            topicName: topic.name,
            questions: this.generateQuizQuestions(subject.name, topic.name),
            answers: [],
            currentIndex: 0
        };

        this.renderQuizQuestion();
        document.getElementById('quizModal')?.classList.add('active');
    }

    generateQuizQuestions(subjectName, topicName) {
        const subjectBank = COMPUTER_SEM4_MCQ_BANK[subjectName];
        if (subjectBank && subjectBank[topicName]) {
            return subjectBank[topicName];
        }

        return [
            {
                question: `When you begin studying "${topicName}" in ${subjectName}, what should come first?`,
                options: ['Understand the core concept and definitions', 'Memorize random facts only', 'Skip directly to the exam', 'Ignore the difficult parts'],
                correct: 0
            },
            {
                question: `If you are weak in "${topicName}", what is the best adaptive response?`,
                options: ['Remove it from the planner', 'Allocate more review time and retry the quiz', 'Study unrelated subjects instead', 'Only read the title again'],
                correct: 1
            },
            {
                question: `Near the exam, how should you revise "${topicName}"?`,
                options: ['Use short focused revision and quick self-testing', 'Start a completely new syllabus', 'Avoid practice questions', 'Study without breaks for the entire night'],
                correct: 0
            }
        ];
    }

    renderQuizQuestion() {
        const container = document.getElementById('quizContainer');
        if (!container || !this.quizState) return;
        const question = this.quizState.questions[this.quizState.currentIndex];
        if (!question) {
            this.finishQuiz();
            return;
        }

        container.innerHTML = `
            <div class="mcq-container">
                <div class="mcq-header">
                    <h3>${this.escapeHtml(this.quizState.subjectName)} • ${this.escapeHtml(this.quizState.topicName)}</h3>
                    <div class="mcq-progress">
                        <div class="progress-bar"><div class="progress-bar-fill" style="width: ${Math.round((this.quizState.currentIndex / this.quizState.questions.length) * 100)}%"></div></div>
                        <span>Q${this.quizState.currentIndex + 1}/${this.quizState.questions.length}</span>
                    </div>
                </div>
                <div class="mcq-question">${this.escapeHtml(question.question)}</div>
                <div class="mcq-options">
                    ${question.options.map((option, index) => `
                        <label class="option-btn quiz-option">
                            <input type="radio" name="quizAnswer" value="${index}">
                            <span>${this.escapeHtml(option)}</span>
                        </label>
                    `).join('')}
                </div>
                <div class="mcq-controls"><button type="button" class="btn btn-primary" id="quizNextBtn">${this.quizState.currentIndex === this.quizState.questions.length - 1 ? 'Finish Quiz' : 'Next Question'}</button></div>
            </div>
        `;
    }

    submitQuizAnswer() {
        if (!this.quizState) return;
        const selected = document.querySelector('input[name="quizAnswer"]:checked');
        if (!selected) {
            alert('Select an answer before continuing.');
            return;
        }
        this.quizState.answers.push(Number(selected.value));
        this.quizState.currentIndex += 1;
        this.renderQuizQuestion();
    }

    finishQuiz() {
        const container = document.getElementById('quizContainer');
        if (!container || !this.quizState) return;

        const score = this.quizState.questions.reduce((total, question, index) => total + (question.correct === this.quizState.answers[index] ? 1 : 0), 0);
        const percent = Math.round((score / this.quizState.questions.length) * 100);
        const key = `${this.quizState.subjectId}::${this.quizState.topicId}`;

        this.state.quizResults[key] = {
            percent,
            attempts: (this.state.quizResults[key]?.attempts || 0) + 1,
            updatedAt: new Date().toISOString()
        };

        const completedTopic = this.findTopic(this.quizState.subjectId, this.quizState.topicId);
        if (completedTopic) {
            completedTopic.completed = true;
        }

        this.recordStudyDay();
        this.pushActivity(`Quiz completed for ${this.quizState.topicName} with ${percent}% score.`);
        this.state.plan = planner.generatePlan(this.state.profile);
        this.updateAchievements();
        this.saveState();
        container.innerHTML = `
            <div class="mcq-score">
                <h2>Quiz Complete</h2>
                <div class="mcq-score-value">${percent}%</div>
                <div class="mcq-score-text">${score}/${this.quizState.questions.length} correct answers</div>
                <p style="margin-top: 1rem; color: var(--text-secondary);">${percent >= 80 ? 'Strong result. You are ready to revise and move ahead.' : 'Review the topic once more and retry the quiz later.'}</p>
                <div class="mcq-controls" style="justify-content: center; margin-top: 1.5rem;"><button type="button" class="btn btn-primary" id="quizCloseBtn">Close</button></div>
            </div>
        `;
        this.quizState = null;
        this.renderAll();
    }

    renderQuizQuestion() {
        const container = document.getElementById('quizContainer');
        if (!container || !this.quizState) return;

        const question = this.quizState.questions[this.quizState.currentIndex];
        if (!question) {
            this.finishQuiz();
            return;
        }

        const selectedAnswer = this.quizState.answers[this.quizState.currentIndex];
        const isAnswered = selectedAnswer !== undefined;
        const correctOption = question.options[question.correct];
        const explanation = question.explanation || `Correct answer: ${String.fromCharCode(65 + question.correct)}. ${correctOption}.`;

        container.innerHTML = `
            <div class="mcq-container">
                <div class="mcq-header">
                    <h3>${this.escapeHtml(this.quizState.subjectName)} - ${this.escapeHtml(this.quizState.topicName)}</h3>
                    <div class="mcq-progress">
                        <div class="progress-bar"><div class="progress-bar-fill" style="width: ${Math.round((this.quizState.currentIndex / this.quizState.questions.length) * 100)}%"></div></div>
                        <span>Q${this.quizState.currentIndex + 1}/${this.quizState.questions.length}</span>
                    </div>
                </div>
                <div class="mcq-question">${this.escapeHtml(question.question)}</div>
                <div class="mcq-options">
                    ${question.options.map((option, index) => `
                        <label class="option-btn quiz-option ${isAnswered && index === question.correct ? 'correct' : ''} ${isAnswered && index === selectedAnswer && index !== question.correct ? 'incorrect' : ''}">
                            <input type="radio" name="quizAnswer" value="${index}" ${selectedAnswer === index ? 'checked' : ''} ${isAnswered ? 'disabled' : ''}>
                            <span>${this.escapeHtml(option)}</span>
                        </label>
                    `).join('')}
                </div>
                ${isAnswered ? `
                    <div class="mcq-feedback ${selectedAnswer === question.correct ? 'feedback-correct' : 'feedback-incorrect'}">
                        ${selectedAnswer === question.correct ? 'Correct answer' : 'Incorrect answer'}
                    </div>
                    <div class="mcq-explanation">
                        <strong>Answer:</strong> ${String.fromCharCode(65 + question.correct)}. ${this.escapeHtml(correctOption)}<br>
                        <strong>Explanation:</strong> ${this.escapeHtml(explanation)}
                    </div>
                ` : ''}
                <div class="mcq-controls">
                    <button type="button" class="btn btn-primary" id="quizNextBtn">
                        ${isAnswered ? (this.quizState.currentIndex === this.quizState.questions.length - 1 ? 'Finish Quiz' : 'Next Question') : 'Check Answer'}
                    </button>
                </div>
            </div>
        `;
    }

    submitQuizAnswer() {
        if (!this.quizState) return;

        if (this.quizState.answers[this.quizState.currentIndex] !== undefined) {
            this.quizState.currentIndex += 1;
            this.renderQuizQuestion();
            return;
        }

        const selected = document.querySelector('input[name="quizAnswer"]:checked');
        if (!selected) {
            alert('Select an answer before continuing.');
            return;
        }

        this.quizState.answers[this.quizState.currentIndex] = Number(selected.value);
        this.renderQuizQuestion();
    }

    getMetrics() {
        const subjects = this.state.profile?.subjects || [];
        const totalTopics = subjects.reduce((sum, subject) => sum + subject.topics.length, 0);
        const completedTopics = subjects.reduce((sum, subject) => sum + subject.topics.filter((topic) => topic.completed).length, 0);
        const remainingTopics = Math.max(0, totalTopics - completedTopics);
        const daysLeft = this.state.profile?.examDate ? this.getDaysUntilExam(this.state.profile.examDate) : 0;
        const remainingHours = daysLeft * (this.state.profile?.availableHours || 0);
        const progressPercent = totalTopics ? Math.round((completedTopics / totalTopics) * 100) : 0;

        return {
            totalTopics,
            completedTopics,
            remainingTopics,
            daysLeft,
            remainingHours,
            progressPercent,
            averageQuizScore: this.getAverageQuizScore()
        };
    }

    getAverageQuizScore() {
        const results = Object.values(this.state.quizResults || {});
        if (!results.length) return 0;
        return Math.round(results.reduce((sum, result) => sum + result.percent, 0) / results.length);
    }

    getSubjectQuizAverage(subjectId) {
        const results = Object.entries(this.state.quizResults || {})
            .filter(([key]) => key.startsWith(`${subjectId}::`))
            .map(([, value]) => value.percent);
        if (!results.length) return 0;
        return Math.round(results.reduce((sum, value) => sum + value, 0) / results.length);
    }

    getQuizBadge(subjectId, topicId) {
        const result = this.state.quizResults[`${subjectId}::${topicId}`];
        return result ? `Quiz ${result.percent}%` : 'Quiz pending';
    }

    getQuizButtonLabel(subjectId, topicId) {
        return this.state.quizResults[`${subjectId}::${topicId}`] ? 'Retry Quiz' : 'Take Quiz';
    }

    getWeakestSubject() {
        if (!this.state.profile?.subjects?.length) return null;
        return this.state.profile.subjects
            .map((subject) => {
                const completed = subject.topics.filter((topic) => topic.completed).length;
                return { name: subject.name, percent: subject.topics.length ? (completed / subject.topics.length) * 100 : 0 };
            })
            .sort((a, b) => a.percent - b.percent)[0];
    }

    getRandomQuote() {
        return MOTIVATIONAL_QUOTES[Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length)];
    }

    recordStudyDay(dateKey = this.todayISO()) {
        const studyLog = Array.isArray(this.state.studyLog) ? this.state.studyLog : [];
        if (!studyLog.includes(dateKey)) {
            studyLog.push(dateKey);
            studyLog.sort();
            this.state.studyLog = studyLog.slice(-30);
        }
    }

    updateAchievements() {
        if (!this.state.achievements) {
            this.state.achievements = {
                firstQuiz: false,
                studyStreak: false,
                perfectScore: false
            };
        }

        const quizResults = Object.values(this.state.quizResults || {});
        this.state.achievements.firstQuiz = quizResults.length > 0;
        this.state.achievements.perfectScore = quizResults.some((result) => result.percent === 100);
        this.state.achievements.studyStreak = this.hasThreeDayStreak();
    }

    hasThreeDayStreak() {
        const uniqueDates = [...new Set(this.state.studyLog || [])].sort();
        if (uniqueDates.length < 3) return false;

        let streak = 1;
        for (let index = 1; index < uniqueDates.length; index += 1) {
            const current = this.parseDateValue(uniqueDates[index]);
            const previous = this.parseDateValue(uniqueDates[index - 1]);
            current.setHours(0, 0, 0, 0);
            previous.setHours(0, 0, 0, 0);

            const dayDiff = Math.round((current - previous) / 86400000);
            streak = dayDiff === 1 ? streak + 1 : 1;

            if (streak >= 3) return true;
        }

        return false;
    }

    handlePlannerInputChange() {
        if (!this.state.profile) return;

        const examDate = document.getElementById('examDate')?.value || this.state.profile.examDate || '';
        const availableHours = Number(document.getElementById('availableHours')?.value || this.state.profile.availableHours || 0);

        this.state.profile = {
            ...this.state.profile,
            examDate,
            availableHours
        };

        if (this.state.plan) {
            const updatedPlan = planner.generatePlan(this.state.profile);
            this.state.plan = updatedPlan.error ? null : updatedPlan;
        }

        this.saveState();
        this.renderSemesterSubjectsPreview();
        this.renderDashboard();
        this.renderSchedulePage();
    }

    getTimeAllocationPreview(profile) {
        const subjects = profile?.subjects || [];
        const pendingSubjects = subjects
            .map((subject) => ({
                id: subject.id,
                name: subject.name,
                difficulty: subject.difficulty || 'moderate',
                weight: this.getDifficultyWeight(subject.difficulty),
                activeTopics: subject.topics.filter((topic) => !topic.completed)
            }))
            .filter((subject) => subject.activeTopics.length > 0);

        const dailyHours = Math.max(subjects.length, Number(profile?.availableHours || 0));
        const daysUntilExam = this.getDaysUntilExam(profile?.examDate);
        const totalHoursUntilExam = Math.max(0, daysUntilExam * dailyHours);
        const subjectMap = {};
        const minimumTotal = pendingSubjects.length;
        const extraHours = Math.max(0, dailyHours - minimumTotal);
        const totalWeight = pendingSubjects.reduce((sum, subject) => sum + subject.weight, 0) || 1;

        pendingSubjects.forEach((subject) => {
            const dailyHoursForSubject = 1 + (extraHours * subject.weight) / totalWeight;
            const totalHoursForSubject = dailyHoursForSubject * daysUntilExam;
            const topicDailyHours = subject.activeTopics.length ? dailyHoursForSubject / subject.activeTopics.length : 0;
            const topicTotalHours = subject.activeTopics.length ? totalHoursForSubject / subject.activeTopics.length : 0;

            subjectMap[subject.id] = {
                difficulty: subject.difficulty,
                dailyHours: dailyHoursForSubject,
                totalHours: totalHoursForSubject,
                topicDailyHours,
                topicTotalHours,
                activeTopicIds: new Set(subject.activeTopics.map((topic) => topic.id))
            };
        });

        return {
            hasExamDate: Boolean(profile?.examDate),
            daysUntilExam,
            dailyHours,
            totalHoursUntilExam,
            subjectMap
        };
    }

    getSubjectAllocationText(subject, allocation) {
        const subjectAllocation = allocation?.subjectMap?.[subject.id];
        if (!subjectAllocation) {
            return allocation?.hasExamDate
                ? `No pending time needed for ${subject.name}. Use this for revision.`
                : 'Select an exam date to see subject time allocation.';
        }

        const dailyText = this.formatDuration(subjectAllocation.dailyHours);
        const totalText = this.formatDuration(subjectAllocation.totalHours);
        return `Difficulty: ${subjectAllocation.difficulty}. ${dailyText} per day for ${subject.name} (${totalText} total until exam).`;
    }

    getTopicAllocationText(subject, topic, allocation) {
        const subjectAllocation = allocation?.subjectMap?.[subject.id];
        if (!subjectAllocation) {
            return topic.completed ? 'Topic completed.' : 'Select an exam date to see topic time allocation.';
        }

        if (!subjectAllocation.activeTopicIds.has(topic.id)) {
            return 'Topic completed.';
        }

        const dailyText = this.formatDuration(subjectAllocation.topicDailyHours);
        const totalText = this.formatDuration(subjectAllocation.topicTotalHours);
        return `Spend ${dailyText} per day on ${topic.name} (${totalText} total).`;
    }

    getSubjectTimeBreakdown() {
        if (!this.state.plan?.sessions?.length) {
            return '<div class="summary-row"><strong>Subject Time:</strong><span>Revision only</span></div>';
        }

        const totals = this.state.plan.sessions.reduce((acc, session) => {
            acc[session.subjectName] = (acc[session.subjectName] || 0) + Number(session.durationHours || 0);
            return acc;
        }, {});

        const formatted = Object.entries(totals)
            .sort(([, hoursA], [, hoursB]) => hoursB - hoursA)
            .map(([subjectName, hours]) => `${this.escapeHtml(subjectName)}: ${this.formatHours(hours)} hr`)
            .join(', ');

        return `<div class="summary-row"><strong>Subject Time:</strong><span>${formatted || 'Revision only'}</span></div>`;
    }

    formatHours(hours) {
        const rounded = Math.round(hours * 10) / 10;
        return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
    }

    formatDuration(hours) {
        const minutes = Math.max(0, Math.round(Number(hours || 0) * 60));
        if (minutes >= 60 && minutes % 60 === 0) {
            const wholeHours = minutes / 60;
            return `${wholeHours} hour${wholeHours === 1 ? '' : 's'}`;
        }
        if (minutes >= 60) {
            const wholeHours = Math.floor(minutes / 60);
            const remainingMinutes = minutes % 60;
            return `${wholeHours} hr ${remainingMinutes} min`;
        }
        return `${minutes} minute${minutes === 1 ? '' : 's'}`;
    }

    getDifficultyWeight(difficulty = 'moderate') {
        const weights = {
            easy: 1,
            moderate: 2,
            difficult: 3
        };
        return weights[difficulty] || weights.moderate;
    }

    getDaysUntilExam(examDate) {
        if (!examDate) return 0;
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const exam = this.parseDateValue(examDate);
        exam.setHours(0, 0, 0, 0);
        if (Number.isNaN(exam.getTime())) return 0;
        return Math.max(0, Math.ceil((exam - today) / 86400000));
    }

    parseDateValue(value) {
        if (!value) return new Date('');
        if (value instanceof Date) return new Date(value);
        if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
            const [year, month, day] = value.split('-').map(Number);
            return new Date(year, month - 1, day);
        }
        return new Date(value);
    }

    pushActivity(message) {
        this.state.activityLog.unshift({ message, timestamp: new Date().toISOString() });
        this.state.activityLog = this.state.activityLog.slice(0, 20);
    }

    pushAdjustment(message) {
        this.state.adjustmentLog.unshift({ message, timestamp: new Date().toISOString() });
        this.state.adjustmentLog = this.state.adjustmentLog.slice(0, 20);
    }

    groupSessionsByDate(sessions) {
        return sessions.reduce((groups, session) => {
            if (!groups[session.date]) groups[session.date] = [];
            groups[session.date].push(session);
            return groups;
        }, {});
    }

    buildStudyPlanWeeks(sessions) {
        const grouped = this.groupSessionsByDate(sessions);
        const orderedDates = Object.keys(grouped).sort();
        if (!orderedDates.length) return [];

        const firstDate = this.parseDateValue(orderedDates[0]);
        const lastDate = this.parseDateValue(orderedDates[orderedDates.length - 1]);
        const firstMonday = this.startOfWeekMonday(firstDate);
        const lastSunday = this.endOfWeekSunday(lastDate);
        const weeks = [];
        let cursor = new Date(firstMonday);

        while (cursor <= lastSunday) {
            const week = [];

            for (let index = 0; index < 7; index += 1) {
                const currentDate = new Date(cursor);
                currentDate.setDate(cursor.getDate() + index);
                const dateKey = this.dateToKey(currentDate);
                const sessionsForDay = grouped[dateKey] || [];

                week.push({
                    date: dateKey,
                    label: currentDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
                    weekday: currentDate.toLocaleDateString('en-US', { weekday: 'long' }),
                    sessions: sessionsForDay
                });
            }

            weeks.push(week);
            cursor.setDate(cursor.getDate() + 7);
        }

        return weeks;
    }

    startOfWeekMonday(date) {
        const clone = this.parseDateValue(date);
        const day = clone.getDay();
        const diff = day === 0 ? -6 : 1 - day;
        clone.setDate(clone.getDate() + diff);
        clone.setHours(0, 0, 0, 0);
        return clone;
    }

    endOfWeekSunday(date) {
        const clone = this.startOfWeekMonday(date);
        clone.setDate(clone.getDate() + 6);
        return clone;
    }

    dateToKey(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    getDayNumberFromSessions(sessions) {
        if (!sessions.length || !this.state.plan?.sessions?.length) return '';
        const groupedDates = Object.keys(this.groupSessionsByDate(this.state.plan.sessions)).sort();
        return groupedDates.indexOf(sessions[0].date) + 1;
    }

    slugify(value) {
        return value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    }

    todayISO() {
        const today = new Date();
        const year = today.getFullYear();
        const month = String(today.getMonth() + 1).padStart(2, '0');
        const day = String(today.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    formatDate(dateString) {
        const date = this.parseDateValue(dateString);
        if (Number.isNaN(date.getTime())) return '';
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    }

    formatDateTime(dateString) {
        return new Date(dateString).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    }

    escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.app = new StudyApp();
});
